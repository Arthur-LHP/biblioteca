<?php

require_once __DIR__ . '/../config/conexao.php';

function listarEditoras() {
    global $conn;

    $sql = "SELECT * FROM editora ORDER BY nome_editora ASC";
    $resultado = $conn->query($sql);

    if (!$resultado) {
        return [];
    }

    return $resultado->fetch_all(MYSQLI_ASSOC);
}

function buscarEditoraPorId($id) {
    global $conn;

    $stmt = $conn->prepare("SELECT * FROM editora WHERE id_editora = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    return $resultado->fetch_assoc();
}
