<?php
require_once __DIR__ . '/config/constants.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ((!isset($_SESSION["tipo"]) && !isset($_SESSION["perfil"])) || !in_array(strtolower($_SESSION["tipo"] ?? $_SESSION["perfil"] ?? ''), ["bibliotecario"], true)) {
    header("Location: " . BASE_URL . "/index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Biblioteca - Painel do Bibliotecário</title>

    <!-- Bootstrap -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <link
        rel="stylesheet"
        href="<?= CSS_URL ?>/catalogo.css">

    <link
        rel="stylesheet"
        href="<?= CSS_URL ?>/padrao.css">

</head>

<body>

    <?php require_once __DIR__ . '/include/header.php'; ?>

    <main>

        <?php

        $categorias = [

            [
                "imagem" => "icon_usuario.png",
                "titulo" => "Usuários",
                "link" => BASE_URL . "/views/usuario/usuario_listar.php"
            ],

            [
                "imagem" => "icon_livro.png",
                "titulo" => "Livros",
                "link" => BASE_URL . "/views/livro/livro_listar.php"
            ],

            [
                "imagem" => "icon_autor.png",
                "titulo" => "Autores",
                "link" => BASE_URL . "/views/autor/autor_listar.php"
            ],

            [
                "imagem" => "icon_categoria.png",
                "titulo" => "Categorias",
                "link" => BASE_URL . "/views/categoria/categoria_listar.php"
            ],

            [
                "imagem" => "icon_autor.png",
                "titulo" => "Editoras",
                "link" => BASE_URL . "/views/editora/editora_listar.php"
            ],

            [
                "imagem" => "icon_emprestimo.png",
                "titulo" => "Empréstimos",
                "link" => BASE_URL . "/views/emprestimo/emprestimo_listar.php"
            ],

            [
                "imagem" => "icon_reserva.png",
                "titulo" => "Reservas",
                "link" => BASE_URL . "/views/reserva/reserva_listar.php"
            ],

            [
                "imagem" => "icon_multa.png",
                "titulo" => "Multas",
                "link" => BASE_URL . "/views/multa/multa_listar.php"
            ],

        ];

        ?>

        <div class="container mt-5">

            <div class="categorias-grid">

                <?php foreach ($categorias as $categoria): ?>

                    <a
                        href="<?= htmlspecialchars($categoria['link']) ?>"
                        class="livro-card rounded-3 shadow"
                    >

                        <img
                            src="<?= UPLOADS_URL ?>/opcoes_bibliotecario/<?= htmlspecialchars($categoria['imagem']) ?>"
                            alt="<?= htmlspecialchars($categoria['titulo']) ?>"
                        >

                        <div class="livro-info">

                            <h5>
                                <?= htmlspecialchars($categoria['titulo']) ?>
                            </h5>

                        </div>

                    </a>

                <?php endforeach; ?>

            </div>

        </div>

    </main>

    <?php require_once __DIR__ . '/include/footer.php'; ?>

    <!-- Bootstrap JS -->
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js">
    </script>

</body>

</html>