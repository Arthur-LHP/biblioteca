<?php
require_once __DIR__ . '/../../config/constants.php';
?>

<!doctype html>
<html lang="pt-br" data-bs-theme="light">

<head>
    <title>Cadastrar Reserva</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >
    <link rel="stylesheet" href="<?= CSS_URL ?>/reserva/reserva_cadastrar.css">
</head>

<body>

<div class="container-fluid container-cadastro">

    <div class="row h-100">


        <div class="col-lg-7 lado-imagem">

            <img
                src="<?= IMG_URL ?>/livros_escada.svg"
                class="img-fluid"
                alt="Biblioteca"
            >

        </div>



        <div class="col-lg-5 lado-form">

            <div class="cadastro-card">

                <div class="logo">
                    <span class="azul">BIBLIO</span><span class="amarelo">TECA</span>
                </div>

                <h3 class="text-center mb-4">
                    Cadastro de Reserva
                </h3>


                <form
                    action="autenticacao.php"
                    method="POST"
                    enctype="multipart/form-data"
                >


                    <div class="mb-3">

                        <label for="nome" class="form-label">
                            Nome do leitor
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="nome"
                            name="email"
                            placeholder="Digite o nome do leitor"
                            required
                        >

                    </div>



                    <div class="mb-3">

                        <label for="livro" class="form-label">
                            Livro
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="livro"
                            name="data"
                            placeholder="Digite o nome do livro"
                            required
                        >

                    </div>



                    <div class="row">

                        <div class="col-md-6">

                            <div class="mb-3">

                                <label for="dataa" class="form-label">
                                    Data da reserva
                                </label>

                                <input
                                    type="date"
                                    class="form-control"
                                    id="dataa"
                                    name="dataa"
                                >

                            </div>

                        </div>


                        <div class="col-md-6">

                            <div class="mb-3">

                                <label for="obras" class="form-label">
                                    Data de devolução
                                </label>

                                <input
                                    type="date"
                                    class="form-control"
                                    id="obras"
                                    name="obras"
                                    required
                                >

                            </div>

                        </div>

                    </div>


                    <button
                        type="submit"
                        class="btn btn-cadastro w-100 mt-2"
                    >
                        Cadastrar reserva
                    </button>



                    <button
                        type="reset"
                        class="btn btn-outline-secondary w-100 mt-2"
                    >
                        Limpar formulário
                    </button>


                    <div class="text-center mt-3">

                        <a href="<?= BASE_URL ?>/views/reserva/reserva_opcoes.php" class="fw-semibold">
                            Voltar
                        </a>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>

</body>

</html>