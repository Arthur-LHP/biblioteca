<?php
require_once __DIR__ . '/../../config/constants.php';
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css"
        rel="stylesheet">
    <title>Opções de Relatório</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/CSS/catalogo.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/CSS/usuario/usuario_opcoes.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/CSS/padrao.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">

</head>

<body>
    
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm border-0">
                    <div class="card-body text-center p-5">
                        <h1 class="h3 mb-3">Módulo em manutenção</h1>
                        <p class="text-muted mb-4">Essa funcionalidade ainda está sendo finalizada.</p>
                        <a href="<?= BASE_URL ?>/bibliotecario.php" class="btn btn-primary">Voltar para o painel do bibliotecário</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>