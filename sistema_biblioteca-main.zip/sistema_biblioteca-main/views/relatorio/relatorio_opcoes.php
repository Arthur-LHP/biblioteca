<?php
require_once __DIR__ . '/../../config/constants.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$perfilAtual = strtolower((string) ($_SESSION["tipo"] ?? $_SESSION["perfil"] ?? ''));
if ((!isset($_SESSION["tipo"]) && !isset($_SESSION["perfil"])) || !in_array($perfilAtual, ["admin", "administrador"], true)) {
    header("Location: " . BASE_URL . "/admin.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="pt-br">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css"
        rel="stylesheet">
    <title>Opções de Usuário</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= CSS_URL ?>/catalogo.css">
    <link rel="stylesheet" href="<?= CSS_URL ?>/usuario/usuario_opcoes.css">
    <link rel="stylesheet" href="<?= CSS_URL ?>/padrao.css">

</head>

<main>

    <body>


        <?php require_once __DIR__ . '/../../include/header.php'; ?>

        <?php

        $categorias = [
            [
                "imagem" => "icon_relatorio.png",
                "titulo" => "Relatórios dos Usuários",
                "link" => BASE_URL . "/views/relatorio/relatorio_usuarios.php"
            ],
            [
                "imagem" => "icon_relatorio.png",
                "titulo" => "Relatórios dos Livros",
                "link" => BASE_URL . "/views/relatorio/relatorio_livros.php"
            ],
            [
                "imagem" => "icon_relatorio.png",
                "titulo" => "Relatórios das multas",
                "link" => BASE_URL . "/views/relatorio/relatorio_multas.php"
            ],
            [
                "imagem" => "icon_relatorio.png",
                "titulo" => "Relatórios dos empréstimos",
                "link" => BASE_URL . "/views/relatorio/relatorio_emprestimos.php"
            ],
        ];

        ?>

        <a href="<?= BASE_URL ?>/admin.php" class="btn-voltar">
            <i class="bi bi-arrow-left"></i>
        </a>

        <div class="container mt-5">
            <h2 class="mb-4">Opções de Relatório</h2>
            <div class="carousel-livros">
                <div class="row mb-4 categorias-grid">
                    <?php foreach ($categorias as $categoria): ?>

                        <a href="<?= $categoria['link'] ?>" class="livro-card rounded-3 shadow">
                            <img src="<?= UPLOADS_URL ?>/opcoes_bibliotecario/<?= $categoria['imagem'] ?>">
                            <div class="livro-info">
                                <h5><?= $categoria['titulo'] ?></h5>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>


        <script>



        </script>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</main>

<?php require_once __DIR__ . '/../../include/footer.php'; ?>


</body>

</html>
</body>

</html>