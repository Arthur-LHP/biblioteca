<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$livro = null;

if ($id > 0) {
    $sql = "SELECT l.*, e.nome_editora,
                   GROUP_CONCAT(DISTINCT a.nome_autor ORDER BY a.nome_autor SEPARATOR ', ') AS autores,
                   GROUP_CONCAT(DISTINCT c.nome_categoria ORDER BY c.nome_categoria SEPARATOR ', ') AS categorias
            FROM livro l
            LEFT JOIN editora e ON e.id_editora = l.id_editora
            LEFT JOIN livro_autor la ON la.id_livro = l.id_livro
            LEFT JOIN autor a ON a.id_autor = la.id_autor
            LEFT JOIN livro_categoria lc ON lc.id_livro = l.id_livro
            LEFT JOIN categoria c ON c.id_categoria = lc.id_categoria
            WHERE l.id_livro = ?
            GROUP BY l.id_livro, e.nome_editora";

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $livro = $stmt->get_result()->fetch_assoc();
    }
}

if (!$livro) {
    header('Location: ' . BASE_URL . '/views/livro/catalogo_livros.php');
    exit;
}

$capa = !empty($livro['imagem_capa']) ? UPLOADS_URL . '/capas_livros/' . rawurlencode($livro['imagem_capa']) : BASE_URL . '/assets/img/livros_escada.svg';
$autores = !empty($livro['autores']) ? $livro['autores'] : 'Autor não informado';
$categorias = !empty($livro['categorias']) ? $livro['categorias'] : 'Sem categoria';
$classificacaoIndicativa = !empty($livro['classificacao_indicativa']) ? $livro['classificacao_indicativa'] : 'Não informada';
$descricao = !empty(trim((string) $livro['descricao'])) ? $livro['descricao'] : 'Descrição ainda não cadastrada para este livro.';
?>
<!DOCTYPE html>
<html lang="pt-br" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($livro['titulo']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/CSS/livro/livro_exibir.css">
</head>
<body>
    <main>
        <?php require_once __DIR__ . '/../../include/header.php'; ?>

        <div class="container livro-container">
            <a href="javascript:history.back()" class="btn-voltar">←</a>

            <div class="livro-detalhes">
                <div class="livro-capa">
                    <img src="<?= htmlspecialchars($capa) ?>" alt="<?= htmlspecialchars($livro['titulo']) ?>">
                </div>

                <div class="livro-info-detalhes">
                    <h1><?= htmlspecialchars($livro['titulo']) ?></h1>
                    <h4>Autor: <?= htmlspecialchars($autores) ?></h4>
                    <h5 class="editora-info"><strong>Editora:</strong> <span class="editora-nome"><?= htmlspecialchars($livro['nome_editora'] ?? 'Editora não informada') ?></span></h5>
                    <p class="classificacao-info"><strong>Classificação indicativa:</strong> <span class="classificacao-valor"><?= htmlspecialchars($classificacaoIndicativa) ?></span></p>
                    <p><strong>Categorias:</strong> <?= htmlspecialchars($categorias) ?></p>
                    <hr>
                    <h3>Sinopse</h3>
                    <p><?= nl2br(htmlspecialchars($descricao)) ?></p>

                    <?php if ((int) $livro['quantidade_disponivel'] > 0): ?>
                        <form action="<?= BASE_URL ?>/views/usuario/historico_emprestimos.php" method="POST">
                            <input type="hidden" name="livro_id" value="<?= (int) $livro['id_livro'] ?>">
                            <button type="submit" class="btn btn-primary">Reservar livro</button>
                        </form>
                    <?php else: ?>
                        <button class="btn btn-secondary" disabled>Livro indisponível</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    </main>

    <?php require_once __DIR__ . '/../../include/footer.php'; ?>
</body>
</html>