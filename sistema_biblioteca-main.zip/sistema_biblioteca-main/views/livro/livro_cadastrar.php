<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$mensagem = '';

$result = $conn->query('SELECT id_editora, nome_editora FROM editora WHERE status = "Ativo" ORDER BY nome_editora ASC');
$editoras = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

$result = $conn->query('SELECT id_autor, nome_autor FROM autor WHERE status = "Ativo" ORDER BY nome_autor ASC');
$autores = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

$result = $conn->query('SELECT id_categoria, nome_categoria FROM categoria WHERE status = "Ativo" ORDER BY nome_categoria ASC');
$categorias = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = trim($_POST['titulo'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $idEditora = isset($_POST['id_editora']) && $_POST['id_editora'] !== '' ? (int) $_POST['id_editora'] : null;
    $classificacaoIndicativa = trim($_POST['classificacao_indicativa'] ?? '');
    $quantidadeTotal = isset($_POST['quantidade_total']) ? (int) $_POST['quantidade_total'] : 0;
    $quantidadeDisponivel = isset($_POST['quantidade_disponivel']) ? (int) $_POST['quantidade_disponivel'] : 0;
    $idAutor = isset($_POST['id_autor']) && $_POST['id_autor'] !== '' ? (int) $_POST['id_autor'] : 0;
    $idCategoria = isset($_POST['id_categoria']) && $_POST['id_categoria'] !== '' ? (int) $_POST['id_categoria'] : 0;

    $nomeCapa = null;
    if (isset($_FILES['imagem_capa']) && $_FILES['imagem_capa']['error'] === UPLOAD_ERR_OK) {
        $arquivo = $_FILES['imagem_capa'];
        $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
        $permitidas = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($extensao, $permitidas, true)) {
            $nomeCapa = 'livro_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $extensao;
            $destino = __DIR__ . '/../../uploads/capas_livros/' . $nomeCapa;
            if (!is_dir(__DIR__ . '/../../uploads/capas_livros')) {
                mkdir(__DIR__ . '/../../uploads/capas_livros', 0777, true);
            }
            move_uploaded_file($arquivo['tmp_name'], $destino);
        }
    }

    if ($titulo === '' || $isbn === '') {
        $mensagem = 'Informe o título e o ISBN do livro.';
    } elseif ($idAutor <= 0 || $idCategoria <= 0) {
        $mensagem = 'Selecione um autor e uma categoria para o livro.';
    } elseif ($quantidadeDisponivel > $quantidadeTotal) {
        $mensagem = 'A quantidade disponível não pode ser maior que a quantidade total.';
    } else {
        $stmt = $conn->prepare('SELECT id_livro FROM livro WHERE isbn = ?');
        $stmt->bind_param('s', $isbn);
        $stmt->execute();
        $livroExistente = $stmt->get_result()->fetch_assoc();

        if ($livroExistente) {
            $mensagem = 'Já existe um livro com este ISBN.';
        } else {
            $conn->begin_transaction();

            if ($idEditora === null) {
                $stmt = $conn->prepare('INSERT INTO livro (titulo, isbn, descricao, classificacao_indicativa, quantidade_total, quantidade_disponivel, imagem_capa) VALUES (?, ?, ?, ?, ?, ?, ?)');
                $stmt->bind_param('ssssiss', $titulo, $isbn, $descricao, $classificacaoIndicativa, $quantidadeTotal, $quantidadeDisponivel, $nomeCapa);
            } else {
                $stmt = $conn->prepare('INSERT INTO livro (id_editora, titulo, isbn, descricao, classificacao_indicativa, quantidade_total, quantidade_disponivel, imagem_capa) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
                $stmt->bind_param('issssiss', $idEditora, $titulo, $isbn, $descricao, $classificacaoIndicativa, $quantidadeTotal, $quantidadeDisponivel, $nomeCapa);
            }

            if (!$stmt->execute()) {
                $conn->rollback();
                $mensagem = 'Erro ao cadastrar livro.';
            } else {
                $idLivro = $conn->insert_id;

                $stmtRelacionamento = $conn->prepare('INSERT INTO livro_autor (id_livro, id_autor) VALUES (?, ?)');
                $stmtRelacionamento->bind_param('ii', $idLivro, $idAutor);
                $stmtRelacionamento->execute();

                $stmtRelacionamento = $conn->prepare('INSERT INTO livro_categoria (id_livro, id_categoria) VALUES (?, ?)');
                $stmtRelacionamento->bind_param('ii', $idLivro, $idCategoria);
                $stmtRelacionamento->execute();

                $conn->commit();
                header('Location: ' . BASE_URL . '/views/livro/livro_listar.php');
                exit;
            }
        }
    }
}
?>
<!doctype html>
<html lang="pt-br" data-bs-theme="light">
<head>
    <title>Cadastrar Livro</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/CSS/livro/livro_cadastrar.css">
</head>
<body>
    <div class="container-fluid container-cadastro">
        <div class="row h-100">
            <div class="col-lg-7 lado-imagem">
                <img src="<?= BASE_URL ?>/assets/img/livros_escada.svg" class="img-fluid" alt="Biblioteca">
            </div>
            <div class="col-lg-5 lado-form">
                <div class="cadastro-card">
                    <div class="logo">
                        <span class="azul">BIBLIO</span><span class="amarelo">TECA</span>
                    </div>
                    <h3 class="text-center mb-4">Cadastro de Livros</h3>
                    <?php if ($mensagem !== ''): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($mensagem) ?></div>
                    <?php endif; ?>
                    <form method="POST" enctype="multipart/form-data">
                        <fieldset class="form-section">
                            <legend>Dados do livro</legend>
                            <div class="row g-2">
                                <div class="col-md-7 mb-2">
                                    <label for="titulo" class="form-label">Título do livro</label>
                                    <input type="text" class="form-control" id="titulo" name="titulo" value="<?= htmlspecialchars($_POST['titulo'] ?? '') ?>" required>
                                </div>
                                <div class="col-md-5 mb-2">
                                    <label for="isbn" class="form-label">ISBN</label>
                                    <input type="text" class="form-control" id="isbn" name="isbn" value="<?= htmlspecialchars($_POST['isbn'] ?? '') ?>" required>
                                </div>
                            </div>
                            <div class="mb-2">
                                <label for="descricao" class="form-label">Descrição</label>
                                <textarea class="form-control" id="descricao" name="descricao" rows="3" placeholder="Descreva a obra..." required><?= htmlspecialchars($_POST['descricao'] ?? '') ?></textarea>
                            </div>
                            <div class="mb-2">
                                <label for="imagem_capa" class="form-label">Capa do livro</label>
                                <input type="file" class="form-control" id="imagem_capa" name="imagem_capa" accept="image/*">
                            </div>
                        </fieldset>

                        <fieldset class="form-section">
                            <legend>Detalhes e relacionamento</legend>
                            <div class="row g-2">
                                <div class="col-md-6 mb-2">
                                    <label for="id_editora" class="form-label">Editora</label>
                                    <select class="form-select" id="id_editora" name="id_editora">
                                        <option value="">Selecione a editora</option>
                                        <?php foreach ($editoras as $editora): ?>
                                            <option value="<?= (int)$editora['id_editora'] ?>" <?= (isset($_POST['id_editora']) && (int)$_POST['id_editora'] === (int)$editora['id_editora']) ? 'selected' : '' ?>><?= htmlspecialchars($editora['nome_editora']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <label for="classificacao_indicativa" class="form-label">Classificação indicativa</label>
                                    <select class="form-select" id="classificacao_indicativa" name="classificacao_indicativa" required>
                                        <option value="">Selecione a classificação</option>
                                        <option value="Livre" <?= ((string)($_POST['classificacao_indicativa'] ?? '') === 'Livre') ? 'selected' : '' ?>>Livre</option>
                                        <option value="+10" <?= ((string)($_POST['classificacao_indicativa'] ?? '') === '+10') ? 'selected' : '' ?>>+10</option>
                                        <option value="+12" <?= ((string)($_POST['classificacao_indicativa'] ?? '') === '+12') ? 'selected' : '' ?>>+12</option>
                                        <option value="+14" <?= ((string)($_POST['classificacao_indicativa'] ?? '') === '+14') ? 'selected' : '' ?>>+14</option>
                                        <option value="+16" <?= ((string)($_POST['classificacao_indicativa'] ?? '') === '+16') ? 'selected' : '' ?>>+16</option>
                                        <option value="+18" <?= ((string)($_POST['classificacao_indicativa'] ?? '') === '+18') ? 'selected' : '' ?>>+18</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row g-2">
                                <div class="col-md-6 mb-2">
                                    <label for="quantidade_total" class="form-label">Quantidade total</label>
                                    <input type="number" min="0" class="form-control" id="quantidade_total" name="quantidade_total" value="<?= htmlspecialchars($_POST['quantidade_total'] ?? 1) ?>" required>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <label for="quantidade_disponivel" class="form-label">Quantidade disponível</label>
                                    <input type="number" min="0" class="form-control" id="quantidade_disponivel" name="quantidade_disponivel" value="<?= htmlspecialchars($_POST['quantidade_disponivel'] ?? 1) ?>" required>
                                </div>
                            </div>
                            <div class="row g-2">
                                <div class="col-md-6 mb-2">
                                    <label for="id_autor" class="form-label">Autor</label>
                                    <select class="form-select" id="id_autor" name="id_autor">
                                        <option value="">Selecione o autor</option>
                                        <?php foreach ($autores as $autor): ?>
                                            <option value="<?= (int)$autor['id_autor'] ?>" <?= ((int)($_POST['id_autor'] ?? 0) === (int)$autor['id_autor']) ? 'selected' : '' ?>><?= htmlspecialchars($autor['nome_autor']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <label for="id_categoria" class="form-label">Categoria</label>
                                    <select class="form-select" id="id_categoria" name="id_categoria">
                                        <option value="">Selecione a categoria</option>
                                        <?php foreach ($categorias as $categoria): ?>
                                            <option value="<?= (int)$categoria['id_categoria'] ?>" <?= ((int)($_POST['id_categoria'] ?? 0) === (int)$categoria['id_categoria']) ? 'selected' : '' ?>><?= htmlspecialchars($categoria['nome_categoria']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </fieldset>

                        <div class="row g-2 mt-2">
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-cadastro w-100">Cadastrar</button>
                            </div>
                            <div class="col-md-6">
                                <button type="reset" class="btn btn-outline-secondary w-100">Limpar</button>
                            </div>
                        </div>
                        <div class="text-center mt-3">
                            <a href="<?= BASE_URL ?>/views/livro/livro_listar.php" class="fw-semibold">Voltar</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>