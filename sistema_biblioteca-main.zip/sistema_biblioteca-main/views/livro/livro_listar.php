<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$perfilLogado = strtolower((string) ($_SESSION['perfil'] ?? $_SESSION['tipo'] ?? ''));
$dashboardVoltar = in_array($perfilLogado, ['admin', 'administrador'], true) ? BASE_URL . '/admin.php' : BASE_URL . '/bibliotecario.php';

$sql = 'SELECT l.*, e.nome_editora,
        GROUP_CONCAT(DISTINCT a.nome_autor ORDER BY a.nome_autor SEPARATOR ", ") AS autores,
        GROUP_CONCAT(DISTINCT c.nome_categoria ORDER BY c.nome_categoria SEPARATOR ", ") AS categorias
        FROM livro l
        LEFT JOIN editora e ON e.id_editora = l.id_editora
        LEFT JOIN livro_autor la ON la.id_livro = l.id_livro
        LEFT JOIN autor a ON a.id_autor = la.id_autor
        LEFT JOIN livro_categoria lc ON lc.id_livro = l.id_livro
        LEFT JOIN categoria c ON c.id_categoria = lc.id_categoria
        WHERE l.status = "Ativo"
        GROUP BY l.id_livro
        ORDER BY l.titulo ASC';

$result = $conn->query($sql);
$livros = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">
    <title>Livros</title>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Livros</h2>
                <small class="text-muted">Lista de livros cadastrados</small>
            </div>
            <div class="d-flex gap-2">
                <a href="<?= BASE_URL ?>/views/livro/livro_cadastrar.php" class="btn btn-primary">Novo livro</a>
                <a href="<?= htmlspecialchars($dashboardVoltar) ?>" class="btn btn-outline-secondary">Voltar</a>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Capa</th>
                            <th>Código</th>
                            <th>Título</th>
                            <th>ISBN</th>
                            <th>Editora</th>
                            <th>Autores</th>
                            <th>Categorias</th>
                            <th>Disponíveis</th>
                            <th class="text-center">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($livros)): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted py-4">Nenhum livro cadastrado.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($livros as $livro): ?>
                                <tr>
                                    <td>
                                        <?php $capa = $livro['imagem_capa'] ? LIVROS_URL . '/' . rawurlencode($livro['imagem_capa']) : BASE_URL . '/assets/img/livros_escada.svg'; ?>
                                        <img src="<?= htmlspecialchars($capa) ?>" alt="Capa" style="width: 48px; height: 64px; object-fit: cover; border-radius: 6px;">
                                    </td>
                                    <td><?= htmlspecialchars($livro['id_livro']) ?></td>
                                    <td><?= htmlspecialchars($livro['titulo']) ?></td>
                                    <td><?= htmlspecialchars($livro['isbn']) ?></td>
                                    <td><?= htmlspecialchars($livro['nome_editora'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($livro['autores'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($livro['categorias'] ?? '-') ?></td>
                                    <td><?= (int)$livro['quantidade_disponivel'] ?></td>
                                    <td class="text-center">
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?= BASE_URL ?>/views/livro/livro_editar.php?id=<?= (int)$livro['id_livro'] ?>" class="btn btn-warning">Editar</a>
                                            <a href="<?= BASE_URL ?>/views/livro/livro_excluir.php?id=<?= (int)$livro['id_livro'] ?>" class="btn btn-danger">Excluir</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>