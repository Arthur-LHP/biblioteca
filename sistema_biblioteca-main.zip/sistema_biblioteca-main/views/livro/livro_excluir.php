<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;

    if ($id > 0) {
        $stmt = $conn->prepare('UPDATE livro SET status = ? WHERE id_livro = ?');
        $status = 'Inativo';
        $stmt->bind_param('si', $status, $id);
        $stmt->execute();
    }

    header('Location: ' . BASE_URL . '/views/livro/livro_listar.php');
    exit;
}

$stmt = $conn->prepare('SELECT l.*, e.nome_editora FROM livro l LEFT JOIN editora e ON e.id_editora = l.id_editora WHERE l.id_livro = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$livro = $stmt->get_result()->fetch_assoc();

if (!$livro) {
    header('Location: ' . BASE_URL . '/views/livro/livro_listar.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Inativar Livro</title>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="card shadow-sm mx-auto" style="max-width: 520px;">
            <div class="card-body">
                <h3 class="mb-3">Inativar livro</h3>
                <p>Deseja realmente inativar o livro <strong><?= htmlspecialchars($livro['titulo']) ?></strong>?</p>
                <form method="POST">
                    <input type="hidden" name="id" value="<?= (int)$livro['id_livro'] ?>">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-warning">Confirmar inativação</button>
                        <a href="<?= BASE_URL ?>/views/livro/livro_listar.php" class="btn btn-outline-secondary">Cancelar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>