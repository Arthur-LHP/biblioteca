<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$mensagem = '';

if ($id <= 0) {
    header('Location: ' . BASE_URL . '/views/livro/livro_listar.php');
    exit;
}

$editoras = $conn->query('SELECT id_editora, nome_editora FROM editora WHERE status = "Ativo" ORDER BY nome_editora ASC')->fetch_all(MYSQLI_ASSOC);
$autores = $conn->query('SELECT id_autor, nome_autor FROM autor WHERE status = "Ativo" ORDER BY nome_autor ASC')->fetch_all(MYSQLI_ASSOC);
$categorias = $conn->query('SELECT id_categoria, nome_categoria FROM categoria WHERE status = "Ativo" ORDER BY nome_categoria ASC')->fetch_all(MYSQLI_ASSOC);

$stmt = $conn->prepare('SELECT * FROM livro WHERE id_livro = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$livro = $stmt->get_result()->fetch_assoc();

if (!$livro) {
    header('Location: ' . BASE_URL . '/views/livro/livro_listar.php');
    exit;
}

$autoresSelecionados = [];
$categoriasSelecionadas = [];

$result = $conn->query('SELECT id_autor FROM livro_autor WHERE id_livro = ' . $id);
if ($result) {
    foreach ($result->fetch_all(MYSQLI_ASSOC) as $item) {
        $autoresSelecionados[] = (int) $item['id_autor'];
    }
}

$result = $conn->query('SELECT id_categoria FROM livro_categoria WHERE id_livro = ' . $id);
if ($result) {
    foreach ($result->fetch_all(MYSQLI_ASSOC) as $item) {
        $categoriasSelecionadas[] = (int) $item['id_categoria'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = trim($_POST['titulo'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $idEditora = isset($_POST['id_editora']) && $_POST['id_editora'] !== '' ? (int) $_POST['id_editora'] : null;
    $classificacaoIndicativa = trim($_POST['classificacao_indicativa'] ?? '');
    $quantidadeTotal = isset($_POST['quantidade_total']) ? (int) $_POST['quantidade_total'] : 0;
    $quantidadeDisponivel = isset($_POST['quantidade_disponivel']) ? (int) $_POST['quantidade_disponivel'] : 0;
    $idAutor = isset($_POST['id_autor']) && $_POST['id_autor'] !== '' ? (int) $_POST['id_autor'] : 0;
    $idCategoria = isset($_POST['id_categoria']) && $_POST['id_categoria'] !== '' ? (int) $_POST['id_categoria'] : 0;
    $autoresSelecionados = $idAutor > 0 ? [$idAutor] : [];
    $categoriasSelecionadas = $idCategoria > 0 ? [$idCategoria] : [];

    $nomeCapa = $livro['imagem_capa'];
    if (isset($_FILES['imagem_capa']) && $_FILES['imagem_capa']['error'] === UPLOAD_ERR_OK) {
        $arquivo = $_FILES['imagem_capa'];
        $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
        $permitidas = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($extensao, $permitidas, true)) {
            $nomeCapa = 'livro_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $extensao;
            $destino = __DIR__ . '/../../uploads/capas_livros/' . $nomeCapa;
            if (!is_dir(__DIR__ . '/../../uploads/capas_livros')) {
                mkdir(__DIR__ . '/../../uploads/capas_livros', 0777, true);
            }
            move_uploaded_file($arquivo['tmp_name'], $destino);
        }
    }

    if ($titulo === '' || $isbn === '') {
        $mensagem = 'Informe o título e o ISBN do livro.';
    } elseif ($idAutor <= 0 || $idCategoria <= 0) {
        $mensagem = 'Selecione um autor e uma categoria para o livro.';
    } elseif ($quantidadeDisponivel > $quantidadeTotal) {
        $mensagem = 'A quantidade disponível não pode ser maior que a quantidade total.';
    } else {
        $conn->begin_transaction();

        if ($idEditora === null) {
            $stmt = $conn->prepare('UPDATE livro SET titulo = ?, isbn = ?, descricao = ?, classificacao_indicativa = ?, quantidade_total = ?, quantidade_disponivel = ?, imagem_capa = ? WHERE id_livro = ?');
            $stmt->bind_param('ssssisi', $titulo, $isbn, $descricao, $classificacaoIndicativa, $quantidadeTotal, $quantidadeDisponivel, $nomeCapa, $id);
        } else {
            $stmt = $conn->prepare('UPDATE livro SET id_editora = ?, titulo = ?, isbn = ?, descricao = ?, classificacao_indicativa = ?, quantidade_total = ?, quantidade_disponivel = ?, imagem_capa = ? WHERE id_livro = ?');
            $stmt->bind_param('issssiisi', $idEditora, $titulo, $isbn, $descricao, $classificacaoIndicativa, $quantidadeTotal, $quantidadeDisponivel, $nomeCapa, $id);
        }

        if (!$stmt->execute()) {
            $conn->rollback();
            $mensagem = 'Erro ao atualizar livro.';
        } else {
            $conn->query('DELETE FROM livro_autor WHERE id_livro = ' . $id);
            $conn->query('DELETE FROM livro_categoria WHERE id_livro = ' . $id);

            foreach ($autoresSelecionados as $idAutorSelecionado) {
                $stmtRelacionamento = $conn->prepare('INSERT INTO livro_autor (id_livro, id_autor) VALUES (?, ?)');
                $stmtRelacionamento->bind_param('ii', $id, $idAutorSelecionado);
                $stmtRelacionamento->execute();
            }

            foreach ($categoriasSelecionadas as $idCategoriaSelecionada) {
                $stmtRelacionamento = $conn->prepare('INSERT INTO livro_categoria (id_livro, id_categoria) VALUES (?, ?)');
                $stmtRelacionamento->bind_param('ii', $id, $idCategoriaSelecionada);
                $stmtRelacionamento->execute();
            }

            $conn->commit();
            header('Location: ' . BASE_URL . '/views/livro/livro_listar.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Editar Livro</title>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h3 class="mb-4">Editar Livro</h3>
                        <?php if ($mensagem !== ''): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($mensagem) ?></div>
                        <?php endif; ?>
                        <form method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Título</label>
                                    <input type="text" class="form-control" name="titulo" value="<?= htmlspecialchars($_POST['titulo'] ?? $livro['titulo']) ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">ISBN</label>
                                    <input type="text" class="form-control" name="isbn" value="<?= htmlspecialchars($_POST['isbn'] ?? $livro['isbn']) ?>" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Capa do livro</label>
                                <input type="file" class="form-control" name="imagem_capa" accept="image/*">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Descrição</label>
                                <textarea class="form-control" name="descricao" rows="4" required><?= htmlspecialchars($_POST['descricao'] ?? $livro['descricao'] ?? '') ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Editora</label>
                                <select class="form-select" name="id_editora">
                                    <option value="">Selecione a editora</option>
                                    <?php foreach ($editoras as $editora): ?>
                                        <option value="<?= (int)$editora['id_editora'] ?>" <?= ((int)($_POST['id_editora'] ?? $livro['id_editora']) === (int)$editora['id_editora']) ? 'selected' : '' ?>><?= htmlspecialchars($editora['nome_editora']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Classificação indicativa</label>
                                <select class="form-select" name="classificacao_indicativa" required>
                                    <option value="">Selecione a classificação</option>
                                    <option value="Livre" <?= ((string)($_POST['classificacao_indicativa'] ?? $livro['classificacao_indicativa']) === 'Livre') ? 'selected' : '' ?>>Livre</option>
                                    <option value="+10" <?= ((string)($_POST['classificacao_indicativa'] ?? $livro['classificacao_indicativa']) === '+10') ? 'selected' : '' ?>>+10</option>
                                    <option value="+12" <?= ((string)($_POST['classificacao_indicativa'] ?? $livro['classificacao_indicativa']) === '+12') ? 'selected' : '' ?>>+12</option>
                                    <option value="+14" <?= ((string)($_POST['classificacao_indicativa'] ?? $livro['classificacao_indicativa']) === '+14') ? 'selected' : '' ?>>+14</option>
                                    <option value="+16" <?= ((string)($_POST['classificacao_indicativa'] ?? $livro['classificacao_indicativa']) === '+16') ? 'selected' : '' ?>>+16</option>
                                    <option value="+18" <?= ((string)($_POST['classificacao_indicativa'] ?? $livro['classificacao_indicativa']) === '+18') ? 'selected' : '' ?>>+18</option>
                                </select>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Quantidade total</label>
                                    <input type="number" min="0" class="form-control" name="quantidade_total" value="<?= htmlspecialchars($_POST['quantidade_total'] ?? $livro['quantidade_total']) ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Quantidade disponível</label>
                                    <input type="number" min="0" class="form-control" name="quantidade_disponivel" value="<?= htmlspecialchars($_POST['quantidade_disponivel'] ?? $livro['quantidade_disponivel']) ?>" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="id_autor" class="form-label">Autor</label>
                                <select class="form-select" id="id_autor" name="id_autor">
                                    <option value="">Selecione o autor</option>
                                    <?php foreach ($autores as $autor): ?>
                                        <option value="<?= (int)$autor['id_autor'] ?>" <?= (((int)($_POST['id_autor'] ?? $autoresSelecionados[0] ?? 0)) === (int)$autor['id_autor']) ? 'selected' : '' ?>><?= htmlspecialchars($autor['nome_autor']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="id_categoria" class="form-label">Categoria</label>
                                <select class="form-select" id="id_categoria" name="id_categoria">
                                    <option value="">Selecione a categoria</option>
                                    <?php foreach ($categorias as $categoria): ?>
                                        <option value="<?= (int)$categoria['id_categoria'] ?>" <?= (((int)($_POST['id_categoria'] ?? $categoriasSelecionadas[0] ?? 0)) === (int)$categoria['id_categoria']) ? 'selected' : '' ?>><?= htmlspecialchars($categoria['nome_categoria']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">Salvar</button>
                                <a href="<?= BASE_URL ?>/views/livro/livro_listar.php" class="btn btn-outline-secondary">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>