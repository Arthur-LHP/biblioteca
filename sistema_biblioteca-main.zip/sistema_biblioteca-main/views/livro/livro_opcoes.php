<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../../config/constants.php';

$perfilLogado = strtolower((string) ($_SESSION['tipo'] ?? $_SESSION['perfil'] ?? ''));
if ((!isset($_SESSION["tipo"]) && !isset($_SESSION["perfil"])) || !in_array($perfilLogado, ["admin", "administrador", "bibliotecario"], true)) {
    $dashboardDestino = BASE_URL . '/index.php';
    if (in_array($perfilLogado, ['admin', 'administrador'], true)) {
        $dashboardDestino = BASE_URL . '/admin.php';
    } elseif (in_array($perfilLogado, ['bibliotecario'], true)) {
        $dashboardDestino = BASE_URL . '/bibliotecario.php';
    }
    header('Location: ' . $dashboardDestino);
    exit;
}

header('Location: ' . BASE_URL . '/views/livro/livro_listar.php');
exit;
