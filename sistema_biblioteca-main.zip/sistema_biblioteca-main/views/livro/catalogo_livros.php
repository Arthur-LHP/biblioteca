<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$busca = trim((string) ($_GET['busca'] ?? ''));
$categoryId = isset($_GET['categoria']) ? (int) $_GET['categoria'] : 0;
$termoBusca = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $busca) . '%';

$categorias = [];
if (isset($conn) && $conn instanceof mysqli) {
    $categoriasQuery = $conn->query("SELECT id_categoria, nome_categoria FROM categoria WHERE status = 'Ativo' ORDER BY nome_categoria ASC");
    if ($categoriasQuery) {
        $categorias = $categoriasQuery->fetch_all(MYSQLI_ASSOC);
    }
}

$sql = 'SELECT DISTINCT l.id_livro,
                        l.titulo,
                        l.imagem_capa,
                        e.nome_editora,
                        GROUP_CONCAT(DISTINCT a.nome_autor ORDER BY a.nome_autor SEPARATOR ", ") AS autores
        FROM livro l
        LEFT JOIN editora e ON e.id_editora = l.id_editora
        LEFT JOIN livro_autor la ON la.id_livro = l.id_livro
        LEFT JOIN autor a ON a.id_autor = la.id_autor
        LEFT JOIN livro_categoria lc ON lc.id_livro = l.id_livro
        LEFT JOIN categoria c ON c.id_categoria = lc.id_categoria
        WHERE l.status = "Ativo" AND COALESCE(l.imagem_capa, "") <> ""';

$params = [];
$types = '';

if ($busca !== '') {
    $sql .= ' AND (l.titulo LIKE ? OR a.nome_autor LIKE ? OR e.nome_editora LIKE ?)';
    $params[] = $termoBusca;
    $params[] = $termoBusca;
    $params[] = $termoBusca;
    $types .= 'sss';
}

if ($categoryId > 0) {
    $sql .= ' AND c.id_categoria = ?';
    $params[] = $categoryId;
    $types .= 'i';
}

$sql .= ' GROUP BY l.id_livro, l.titulo, l.imagem_capa, e.nome_editora ORDER BY l.titulo ASC';

$livros = [];
if (isset($conn) && $conn instanceof mysqli) {
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        if ($params !== []) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $livros = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }
}
?>
<!doctype html>
<html lang="pt-br" data-bs-theme="light">
<head>
    <title>Catálogo de Livros</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/CSS/style.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/CSS/padrao.css">
    <style>
        .categoria-botoes { display:flex; flex-wrap:wrap; gap:12px; margin-bottom:24px; }
        .categoria-botoes .btn { border-radius: 999px; padding: .7rem 1.2rem; font-weight:600; }
        .catalogo-header { display:flex; justify-content:space-between; align-items:center; gap:1rem; margin-bottom:1.5rem; }
        .catalogo-grid { display:flex; flex-wrap:wrap; gap:18px; align-items:flex-start; }
        .catalogo-card { width:170px; height:250px; flex:0 0 170px; position:relative; overflow:hidden; border-radius:10px; background:#fff; border:1px solid #d4deea; box-shadow:0 4px 10px rgba(27,37,89,.08); text-decoration:none; color:#1a1a1a; transition:transform .25s ease, box-shadow .25s ease; }
        .catalogo-card:hover { transform:translateY(-6px) scale(1.02); box-shadow:0 10px 22px rgba(27,37,89,.18); }
        .catalogo-card img { width:100%; height:100%; object-fit:cover; display:block; background:#edf2f8; }
        .catalogo-card .livro-info { position:absolute; left:0; bottom:0; width:100%; height:50%; padding:15px 10px; background:linear-gradient(to top, rgba(27,37,89,.96), rgba(27,37,89,.82), rgba(27,37,89,.25)); color:#fff; display:flex; flex-direction:column; justify-content:flex-end; align-items:center; text-align:center; opacity:0; transition:opacity .25s ease; }
        .catalogo-card:hover .livro-info { opacity:1; }
        .catalogo-card .livro-info h5 { width:100%; font-size:15px; margin:0 0 4px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .catalogo-card .livro-info p { width:100%; font-size:12px; margin:0; color:#e8edf5; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .catalogo-card .livro-info strong { color:#fff; }
        @media (max-width: 768px) { .catalogo-header { flex-direction:column; align-items:stretch; } .catalogo-grid { justify-content:center; } }
    </style>
</head>
<body>
    <?php require_once __DIR__ . '/../../include/header.php'; ?>

    <main class="container my-5">
        <div class="catalogo-header">
            <div>
                <h2 class="mb-1">Catálogo</h2>
                <small class="text-muted"><?= $busca !== '' ? 'Resultados para: ' . htmlspecialchars($busca) : 'Livros cadastrados no sistema'; ?></small>
            </div>
            <form method="GET" class="d-flex gap-2 w-100 w-md-auto" style="max-width: 500px;">
                <input type="search" name="busca" class="form-control" value="<?= htmlspecialchars($busca) ?>" placeholder="Buscar por nome, autor ou editora" aria-label="Buscar livro">
                <button type="submit" class="btn btn-primary">Buscar</button>
            </form>
        </div>

        <div class="categoria-botoes">
            <a href="<?= BASE_URL ?>/views/livro/catalogo_livros.php<?= $busca !== '' ? '?busca=' . urlencode($busca) : '' ?>" class="btn <?= $categoryId === 0 ? 'btn-primary' : 'btn-outline-primary' ?>">Todos</a>
            <?php foreach ($categorias as $categoria): ?>
                <?php $categoriaLink = BASE_URL . '/views/livro/catalogo_livros.php?categoria=' . (int) $categoria['id_categoria']; ?>
                <?php if ($busca !== '') { $categoriaLink .= '&busca=' . urlencode($busca); } ?>
                <a href="<?= htmlspecialchars($categoriaLink) ?>" class="btn <?= (int) $categoria['id_categoria'] === $categoryId ? 'btn-primary' : 'btn-outline-primary' ?>"><?= htmlspecialchars($categoria['nome_categoria']) ?></a>
            <?php endforeach; ?>
        </div>

        <?php if ($busca !== '' || $categoryId > 0): ?>
            <div class="mb-4">
                <a href="<?= BASE_URL ?>/views/livro/catalogo_livros.php" class="btn btn-outline-secondary btn-sm">Limpar filtros</a>
            </div>
        <?php endif; ?>

        <?php if (empty($livros)): ?>
            <div class="alert alert-warning">Nenhum livro encontrado para os filtros selecionados.</div>
        <?php else: ?>
            <div class="catalogo-grid">
                <?php foreach ($livros as $livro): ?>
                    <?php $capa = !empty($livro['imagem_capa']) ? UPLOADS_URL . '/capas_livros/' . rawurlencode($livro['imagem_capa']) : BASE_URL . '/assets/img/livros_escada.svg'; ?>
                    <a href="<?= BASE_URL ?>/views/livro/livro_exibir.php?id=<?= (int) $livro['id_livro'] ?>" class="catalogo-card" title="<?= htmlspecialchars($livro['titulo']) ?>">
                        <img src="<?= htmlspecialchars($capa) ?>" alt="<?= htmlspecialchars($livro['titulo']) ?>" style="object-fit:cover;">
                        <div class="livro-info">
                            <h5><?= htmlspecialchars($livro['titulo']) ?></h5>
                            <p><?= htmlspecialchars($livro['autores'] ?? 'Autor não informado') ?></p>
                            <p><strong style="color:#fff;">Editora:</strong> <span style="color:#fff;"><?= htmlspecialchars($livro['nome_editora'] ?? 'Editora não informada') ?></span></p>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

    <?php require_once __DIR__ . '/../../include/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>