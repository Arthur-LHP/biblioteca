<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$mensagem = '';

if ($id <= 0) {
    header('Location: ' . BASE_URL . '/views/autor/autor_listar.php');
    exit;
}

$stmt = $conn->prepare('SELECT * FROM autor WHERE id_autor = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$autor = $stmt->get_result()->fetch_assoc();

if (!$autor) {
    header('Location: ' . BASE_URL . '/views/autor/autor_listar.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome_autor'] ?? '');
    $dataNascimento = $_POST['data_nascimento'] ?? null;
    $dataMorte = $_POST['data_morte'] ?? null;

    if ($nome === '') {
        $mensagem = 'Informe o nome do autor.';
    } else {
        $stmt = $conn->prepare('UPDATE autor SET nome_autor = ?, data_nascimento = ?, data_morte = ? WHERE id_autor = ?');
        $stmt->bind_param('sssi', $nome, $dataNascimento, $dataMorte, $id);

        if ($stmt->execute()) {
            header('Location: ' . BASE_URL . '/views/autor/autor_listar.php');
            exit;
        }

        $mensagem = 'Erro ao atualizar autor.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Editar Autor</title>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h3 class="mb-4">Editar Autor</h3>
                        <?php if ($mensagem !== ''): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($mensagem) ?></div>
                        <?php endif; ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Nome do autor</label>
                                <input type="text" class="form-control" name="nome_autor" value="<?= htmlspecialchars($_POST['nome_autor'] ?? $autor['nome_autor']) ?>" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Data de nascimento</label>
                                    <input type="date" class="form-control" name="data_nascimento" value="<?= htmlspecialchars($_POST['data_nascimento'] ?? ($autor['data_nascimento'] ?? '')) ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Data de morte</label>
                                    <input type="date" class="form-control" name="data_morte" value="<?= htmlspecialchars($_POST['data_morte'] ?? ($autor['data_morte'] ?? '')) ?>">
                                </div>
                            </div>
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">Salvar</button>
                                <a href="<?= BASE_URL ?>/views/autor/autor_listar.php" class="btn btn-outline-secondary">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>