<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome_autor'] ?? '');
    $dataNascimento = $_POST['data_nascimento'] ?? null;
    $dataMorte = $_POST['data_morte'] ?? null;

    if ($nome === '') {
        $mensagem = 'Informe o nome do autor.';
    } else {
        $stmt = $conn->prepare('INSERT INTO autor (nome_autor, data_nascimento, data_morte) VALUES (?, ?, ?)');
        $stmt->bind_param('sss', $nome, $dataNascimento, $dataMorte);

        if ($stmt->execute()) {
            header('Location: ' . BASE_URL . '/views/autor/autor_listar.php');
            exit;
        }

        $mensagem = 'Erro ao cadastrar autor.';
    }
}
?>
<!doctype html>
<html lang="pt-br" data-bs-theme="light">
<head>
    <title>Cadastrar Autor</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/CSS/autor/autor_cadastrar.css">
</head>
<body>
    <div class="container-fluid container-cadastro">
        <div class="row h-100">
            <div class="col-lg-7 lado-imagem">
                <img src="<?= IMG_URL ?>/livros_escada.svg" class="img-fluid" alt="Biblioteca">
            </div>
            <div class="col-lg-5 lado-form">
                <div class="cadastro-card">
                    <div class="logo">
                        <span class="azul">BIBLIO</span><span class="amarelo">TECA</span>
                    </div>
                    <h3 class="text-center mb-4">Cadastro de Autor</h3>
                    <?php if ($mensagem !== ''): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($mensagem) ?></div>
                    <?php endif; ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label for="nome_autor" class="form-label">Nome do autor</label>
                            <input type="text" class="form-control" id="nome_autor" name="nome_autor" value="<?= htmlspecialchars($_POST['nome_autor'] ?? '') ?>" placeholder="Digite o nome do autor" required>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="data_nascimento" class="form-label">Data de nascimento</label>
                                <input type="date" class="form-control" id="data_nascimento" name="data_nascimento" value="<?= htmlspecialchars($_POST['data_nascimento'] ?? '') ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="data_morte" class="form-label">Data de morte</label>
                                <input type="date" class="form-control" id="data_morte" name="data_morte" value="<?= htmlspecialchars($_POST['data_morte'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="row g-2 mt-2">
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-cadastro w-100">Cadastrar</button>
                            </div>
                            <div class="col-md-6">
                                <button type="reset" class="btn btn-outline-secondary w-100">Limpar</button>
                            </div>
                        </div>
                        <div class="text-center mt-3">
                            <a href="<?= BASE_URL ?>/views/autor/autor_listar.php" class="fw-semibold">Voltar</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

