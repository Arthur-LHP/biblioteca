<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$perfilLogado = strtolower((string) ($_SESSION['perfil'] ?? $_SESSION['tipo'] ?? ''));
$dashboardVoltar = in_array($perfilLogado, ['admin', 'administrador'], true) ? BASE_URL . '/admin.php' : BASE_URL . '/bibliotecario.php';

$result = $conn->query('SELECT * FROM categoria ORDER BY nome_categoria ASC');
$categorias = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">
    <title>Categorias</title>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Categorias</h2>
                <small class="text-muted">Lista de categorias cadastradas</small>
            </div>
            <div class="d-flex gap-2">
                <a href="<?= BASE_URL ?>/views/categoria/categoria_cadastrar.php" class="btn btn-primary">Nova categoria</a>
                <a href="<?= htmlspecialchars($dashboardVoltar) ?>" class="btn btn-outline-secondary">Voltar</a>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Código</th>
                            <th>Nome</th>
                            <th>Descrição</th>
                            <th class="text-center">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($categorias)): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">Nenhuma categoria cadastrada.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($categorias as $categoria): ?>
                                <tr>
                                    <td><?= htmlspecialchars($categoria['id_categoria']) ?></td>
                                    <td><?= htmlspecialchars($categoria['nome_categoria']) ?></td>
                                    <td><?= htmlspecialchars($categoria['descricao'] ?? '-') ?></td>
                                    <td class="text-center">
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?= BASE_URL ?>/views/categoria/categoria_editar.php?id=<?= (int)$categoria['id_categoria'] ?>" class="btn btn-warning">Editar</a>
                                            <a href="<?= BASE_URL ?>/views/categoria/categoria_excluir.php?id=<?= (int)$categoria['id_categoria'] ?>" class="btn btn-danger">Excluir</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>