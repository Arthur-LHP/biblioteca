<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$mensagem = '';

if ($id <= 0) {
    header('Location: ' . BASE_URL . '/views/categoria/categoria_listar.php');
    exit;
}

$stmt = $conn->prepare('SELECT * FROM categoria WHERE id_categoria = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$categoria = $stmt->get_result()->fetch_assoc();

if (!$categoria) {
    header('Location: ' . BASE_URL . '/views/categoria/categoria_listar.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome_categoria'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');

    if ($nome === '') {
        $mensagem = 'Informe o nome da categoria.';
    } else {
        $stmt = $conn->prepare('UPDATE categoria SET nome_categoria = ?, descricao = ? WHERE id_categoria = ?');
        $stmt->bind_param('ssi', $nome, $descricao, $id);

        if ($stmt->execute()) {
            header('Location: ' . BASE_URL . '/views/categoria/categoria_listar.php');
            exit;
        }

        $mensagem = 'Erro ao atualizar categoria.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Editar Categoria</title>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h3 class="mb-4">Editar Categoria</h3>
                        <?php if ($mensagem !== ''): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($mensagem) ?></div>
                        <?php endif; ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Nome da categoria</label>
                                <input type="text" class="form-control" name="nome_categoria" value="<?= htmlspecialchars($_POST['nome_categoria'] ?? $categoria['nome_categoria']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Descrição</label>
                                <textarea class="form-control" name="descricao" rows="4"><?= htmlspecialchars($_POST['descricao'] ?? $categoria['descricao']) ?></textarea>
                            </div>
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">Salvar</button>
                                <a href="<?= BASE_URL ?>/views/categoria/categoria_listar.php" class="btn btn-outline-secondary">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>