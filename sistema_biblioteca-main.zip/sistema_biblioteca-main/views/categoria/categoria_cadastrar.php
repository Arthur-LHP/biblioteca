<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome_categoria'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');

    if ($nome === '') {
        $mensagem = 'Informe o nome da categoria.';
    } else {
        $stmt = $conn->prepare('INSERT INTO categoria (nome_categoria, descricao) VALUES (?, ?)');
        $stmt->bind_param('ss', $nome, $descricao);

        if ($stmt->execute()) {
            header('Location: ' . BASE_URL . '/views/categoria/categoria_listar.php');
            exit;
        }

        $mensagem = 'Erro ao cadastrar categoria.';
    }
}
?>
<!doctype html>
<html lang="pt-br" data-bs-theme="light">
<head>
    <title>Cadastrar Categoria</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>/assets/CSS/categoria/categoria_cadastrar.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid container-cadastro">
        <div class="row h-100">
            <div class="col-lg-7 lado-imagem">
                <img src="<?= IMG_URL ?>/livros_escada.svg" class="img-fluid" alt="Biblioteca">
            </div>
            <div class="col-lg-5 lado-form">
                <div class="cadastro-card">
                    <div class="logo">
                        <span class="azul">BIBLIO</span><span class="amarelo">TECA</span>
                    </div>
                    <h3 class="text-center mb-4">Cadastro de Categoria</h3>
                    <?php if ($mensagem !== ''): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($mensagem) ?></div>
                    <?php endif; ?>
                    <form method="POST">
                        <div class="mb-4">
                            <label for="nome_categoria" class="form-label">Categoria</label>
                            <input type="text" class="form-control" id="nome_categoria" name="nome_categoria" value="<?= htmlspecialchars($_POST['nome_categoria'] ?? '') ?>" placeholder="Digite o nome da categoria" required>
                        </div>
                        <div class="mb-4">
                            <label for="descricao" class="form-label">Descrição</label>
                            <textarea class="form-control" id="descricao" name="descricao" rows="3" placeholder="Descreva a categoria"><?= htmlspecialchars($_POST['descricao'] ?? '') ?></textarea>
                        </div>
                        <div class="row g-2">
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-cadastro w-100">Cadastrar</button>
                            </div>
                            <div class="col-md-6">
                                <button type="reset" class="btn btn-outline-secondary w-100">Limpar</button>
                            </div>
                        </div>
                        <div class="text-center mt-3">
                            <a href="<?= BASE_URL ?>/views/categoria/categoria_listar.php" class="fw-semibold">Voltar</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>