<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;

    if ($id > 0) {
        $stmt = $conn->prepare("DELETE FROM editora WHERE id_editora = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }

    header('Location: ' . BASE_URL . '/views/editora/editora_listar.php');
    exit;
}

$stmt = $conn->prepare("SELECT * FROM editora WHERE id_editora = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$editora = $stmt->get_result()->fetch_assoc();

if (!$editora) {
    header('Location: ' . BASE_URL . '/views/editora/editora_listar.php');
    exit;
}
?>
<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Excluir Editora</title>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="card shadow-sm mx-auto" style="max-width: 520px;">
            <div class="card-body">
                <h3 class="mb-3">Excluir editora</h3>
                <p>Deseja realmente excluir a editora <strong><?= htmlspecialchars($editora['nome_editora']) ?></strong>?</p>
                <form method="POST">
                    <input type="hidden" name="id" value="<?= (int)$editora['id_editora'] ?>">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-danger">Confirmar exclusão</button>
                        <a href="<?= BASE_URL ?>/views/editora/editora_listar.php" class="btn btn-outline-secondary">Cancelar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
