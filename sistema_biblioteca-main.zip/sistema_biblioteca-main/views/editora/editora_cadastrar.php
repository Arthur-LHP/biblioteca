<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome_editora'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $site = trim($_POST['site'] ?? '');

    if ($nome === '') {
        $mensagem = 'Informe o nome da editora.';
    } else {
        $stmt = $conn->prepare("INSERT INTO editora (nome_editora, telefone, email, site) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $nome, $telefone, $email, $site);

        if ($stmt->execute()) {
            header('Location: ' . BASE_URL . '/views/editora/editora_listar.php');
            exit;
        }

        $mensagem = 'Erro ao cadastrar editora.';
    }
}
?>
<!doctype html>
<html lang="pt-br" data-bs-theme="light">
<head>
    <title>Cadastrar Editora</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/CSS/usuario/usuario.css">
</head>
<body>
    <div class="container-fluid container-cadastro">
        <div class="row h-100">
            <div class="col-lg-7 lado-imagem">
                <img src="<?= IMG_URL ?>/livros_escada.svg" class="img-fluid" alt="Biblioteca">
            </div>
            <div class="col-lg-5 lado-form">
                <div class="cadastro-card">
                    <div class="logo">
                        <span class="azul">BIBLIO</span><span class="amarelo">TECA</span>
                    </div>
                    <h3 class="text-center mb-4">Cadastro de Editora</h3>
                    <?php if ($mensagem !== ''): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($mensagem) ?></div>
                    <?php endif; ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Nome da editora</label>
                            <input type="text" class="form-control" name="nome_editora" value="<?= htmlspecialchars($_POST['nome_editora'] ?? '') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Telefone</label>
                            <input type="text" class="form-control" name="telefone" value="<?= htmlspecialchars($_POST['telefone'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">E-mail</label>
                            <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Site</label>
                            <input type="url" class="form-control" name="site" value="<?= htmlspecialchars($_POST['site'] ?? '') ?>">
                        </div>
                        <div class="row g-2">
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-cadastro w-100">Cadastrar</button>
                            </div>
                            <div class="col-md-6">
                                <button type="reset" class="btn btn-outline-secondary w-100">Limpar</button>
                            </div>
                        </div>
                        <div class="text-center mt-3">
                            <a href="<?= BASE_URL ?>/views/editora/editora_listar.php" class="fw-semibold">Voltar</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
