<?php
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$mensagem = '';

if ($id <= 0) {
    header('Location: ' . BASE_URL . '/views/editora/editora_listar.php');
    exit;
}

$stmt = $conn->prepare("SELECT * FROM editora WHERE id_editora = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$editora = $stmt->get_result()->fetch_assoc();

if (!$editora) {
    header('Location: ' . BASE_URL . '/views/editora/editora_listar.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome_editora'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $site = trim($_POST['site'] ?? '');

    if ($nome === '') {
        $mensagem = 'Informe o nome da editora.';
    } else {
        $stmt = $conn->prepare("UPDATE editora SET nome_editora = ?, telefone = ?, email = ?, site = ? WHERE id_editora = ?");
        $stmt->bind_param("ssssi", $nome, $telefone, $email, $site, $id);

        if ($stmt->execute()) {
            header('Location: ' . BASE_URL . '/views/editora/editora_listar.php');
            exit;
        }

        $mensagem = 'Erro ao atualizar editora.';
    }
}
?>
<!doctype html>
<html lang="pt-br" data-bs-theme="light">
<head>
    <title>Editar Editora</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/CSS/usuario/usuario.css">
</head>
<body>
    <div class="container-fluid container-cadastro">
        <div class="row h-100">
            <div class="col-lg-7 lado-imagem">
                <img src="<?= IMG_URL ?>/livros_escada.svg" class="img-fluid" alt="Biblioteca">
            </div>
            <div class="col-lg-5 lado-form">
                <div class="cadastro-card">
                    <div class="logo">
                        <span class="azul">BIBLIO</span><span class="amarelo">TECA</span>
                    </div>
                    <h3 class="text-center mb-4">Editar Editora</h3>
                    <?php if ($mensagem !== ''): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($mensagem) ?></div>
                    <?php endif; ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Nome da editora</label>
                            <input type="text" class="form-control" name="nome_editora" value="<?= htmlspecialchars($_POST['nome_editora'] ?? $editora['nome_editora']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Telefone</label>
                            <input type="text" class="form-control" name="telefone" value="<?= htmlspecialchars($_POST['telefone'] ?? $editora['telefone']) ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">E-mail</label>
                            <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($_POST['email'] ?? $editora['email']) ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Site</label>
                            <input type="url" class="form-control" name="site" value="<?= htmlspecialchars($_POST['site'] ?? $editora['site']) ?>">
                        </div>
                        <div class="row g-2">
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-cadastro w-100">Salvar</button>
                            </div>
                            <div class="col-md-6">
                                <a href="<?= BASE_URL ?>/views/editora/editora_listar.php" class="btn btn-outline-secondary w-100">Cancelar</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
