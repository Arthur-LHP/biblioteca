<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$perfilAtual = strtolower((string) ($_SESSION['perfil'] ?? $_SESSION['tipo'] ?? ''));
if ((!isset($_SESSION['tipo']) && !isset($_SESSION['perfil'])) || !in_array($perfilAtual, ['admin', 'administrador'], true)) {
    header('Location: ' . BASE_URL . '/admin.php');
    exit;
}

$mensagem = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = trim((string) ($_POST['tipo'] ?? ''));
    $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
    $mapaTipos = [
        'autor' => ['tabela' => 'autor', 'campo' => 'id_autor'],
        'categoria' => ['tabela' => 'categoria', 'campo' => 'id_categoria'],
        'editora' => ['tabela' => 'editora', 'campo' => 'id_editora'],
        'livro' => ['tabela' => 'livro', 'campo' => 'id_livro'],
    ];

    if (isset($mapaTipos[$tipo]) && $id > 0) {
        $config = $mapaTipos[$tipo];
        $stmt = $conn->prepare('UPDATE ' . $config['tabela'] . ' SET status = ? WHERE ' . $config['campo'] . ' = ?');
        $status = 'Ativo';
        $stmt->bind_param('si', $status, $id);
        if ($stmt->execute()) {
            $mensagem = 'Item reativado com sucesso.';
        } else {
            $mensagem = 'Não foi possível reativar o item.';
        }
    }
}

$itensInativos = [
    'livro' => $conn->query('SELECT id_livro AS id, titulo AS nome, status FROM livro WHERE status = "Inativo" ORDER BY titulo ASC')->fetch_all(MYSQLI_ASSOC),
    'autor' => $conn->query('SELECT id_autor AS id, nome_autor AS nome, status FROM autor WHERE status = "Inativo" ORDER BY nome_autor ASC')->fetch_all(MYSQLI_ASSOC),
    'categoria' => $conn->query('SELECT id_categoria AS id, nome_categoria AS nome, status FROM categoria WHERE status = "Inativo" ORDER BY nome_categoria ASC')->fetch_all(MYSQLI_ASSOC),
    'editora' => $conn->query('SELECT id_editora AS id, nome_editora AS nome, status FROM editora WHERE status = "Inativo" ORDER BY nome_editora ASC')->fetch_all(MYSQLI_ASSOC),
];
$temItensInativos = false;
foreach ($itensInativos as $itens) {
    if (!empty($itens)) {
        $temItensInativos = true;
        break;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Itens inativos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Itens inativos</h2>
                <small class="text-muted">Reative cadastros que estiverem desativados</small>
            </div>
            <a href="<?= BASE_URL ?>/admin.php" class="btn btn-outline-secondary">Voltar</a>
        </div>

        <?php if ($mensagem !== ''): ?>
            <div class="alert alert-success"><?= htmlspecialchars($mensagem) ?></div>
        <?php endif; ?>

        <?php if (!$temItensInativos): ?>
            <div class="alert alert-info">Não há itens inativos no momento.</div>
        <?php endif; ?>

        <?php foreach ($itensInativos as $tipo => $itens): ?>
            <?php if (empty($itens)) continue; ?>
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-dark text-white">
                    <strong><?= ucfirst($tipo) ?>s inativos</strong>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Código</th>
                                <th>Nome</th>
                                <th>Status</th>
                                <th class="text-center">Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($itens as $item): ?>
                                <tr>
                                    <td><?= htmlspecialchars((string) $item['id']) ?></td>
                                    <td><?= htmlspecialchars((string) $item['nome']) ?></td>
                                    <td><span class="badge bg-secondary">Inativo</span></td>
                                    <td class="text-center">
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="tipo" value="<?= htmlspecialchars($tipo) ?>">
                                            <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                                            <button type="submit" class="btn btn-success btn-sm">Reativar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
