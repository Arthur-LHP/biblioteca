<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$mensagem = '';
$perfilLogado = strtolower((string) ($_SESSION['perfil'] ?? $_SESSION['tipo'] ?? ''));
$podeSelecionarPerfil = in_array($perfilLogado, ['admin', 'administrador'], true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome_completo_usuario'] ?? '');
    $cpf = preg_replace('/\D/', '', $_POST['cpf'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $dataNascimento = $_POST['data_nascimento'] ?? null;
    $logradouro = trim($_POST['endereco'] ?? '');
    $numero = trim($_POST['numero_casa'] ?? '');
    $cep = preg_replace('/\D/', '', $_POST['cep'] ?? '');
    $cidadeEstado = trim($_POST['cidade_estado'] ?? '');
    $cidade = $cidadeEstado;
    $estado = '';

    if (preg_match('/\s*\/\s*([A-Za-z]{2})\s*$/', $cidadeEstado, $match)) {
        $cidade = trim(str_replace($match[0], '', $cidadeEstado));
        $estado = strtoupper($match[1]);
    } elseif (preg_match('/\s*-\s*([A-Za-z]{2})\s*$/', $cidadeEstado, $match)) {
        $cidade = trim(str_replace($match[0], '', $cidadeEstado));
        $estado = strtoupper($match[1]);
    }

    $perfil = $podeSelecionarPerfil ? trim((string) ($_POST['perfil'] ?? 'Leitor')) : 'Leitor';
    $perfilPermitido = ['Administrador', 'Bibliotecario', 'Leitor'];
    if ($podeSelecionarPerfil && !in_array($perfil, $perfilPermitido, true)) {
        $perfil = 'Leitor';
    }

    $senha = $_POST['senha'] ?? '';
    $confirmarSenha = $_POST['confirmar_senha'] ?? '';

    if ($nome === '' || $email === '' || $senha === '') {
        $mensagem = 'Preencha todos os dados obrigatórios.';
    } elseif ($senha !== $confirmarSenha) {
        $mensagem = 'As senhas não são iguais.';
    } else {
        $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
        $status = 'Ativo';
        $conn->begin_transaction();

        $stmt = $conn->prepare('INSERT INTO usuario (nome_completo, data_nascimento, telefone, cpf, email, senha, perfil, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->bind_param('ssssssss', $nome, $dataNascimento, $telefone, $cpf, $email, $senhaHash, $perfil, $status);

        if ($stmt->execute()) {
            $idUsuario = $conn->insert_id;
            $stmtEndereco = $conn->prepare('INSERT INTO endereco (id_usuario, logradouro, numero, complemento, bairro, cidade, estado, cep) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            $complemento = '';
            $bairro = '';
            $stmtEndereco->bind_param('isssssss', $idUsuario, $logradouro, $numero, $complemento, $bairro, $cidade, $estado, $cep);

            if ($stmtEndereco->execute()) {
                $conn->commit();
                header('Location: ' . BASE_URL . '/login.php');
                exit;
            }
        }

        $conn->rollback();
        $mensagem = 'Erro ao cadastrar usuário.';
    }
}
?>

<!doctype html>
<html lang="pt-br" data-bs-theme="light">
<head>
    <title>Cadastrar Usuário</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= CSS_URL ?>/usuario/usuario.css">
</head>
<body>
    <div class="container-fluid container-cadastro">
        <div class="row h-100">
            <div class="col-lg-7 lado-imagem">
                <img src="<?= IMG_URL ?>/livros_escada.svg" class="img-fluid" alt="Biblioteca">
            </div>
            <div class="col-lg-5 lado-form">
                <div class="cadastro-card">
                    <div class="logo">
                        <span class="azul">BIBLIO</span><span class="amarelo">TECA</span>
                    </div>
                    <h3 class="text-center mb-4">Cadastrar Usuário</h3>
                    <?php if ($mensagem !== ''): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($mensagem) ?></div>
                    <?php endif; ?>
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Nome completo</label>
                                    <input type="text" class="form-control" name="nome_completo_usuario" value="<?= htmlspecialchars($_POST['nome_completo_usuario'] ?? '') ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">CPF</label>
                                    <input type="text" class="form-control" name="cpf" maxlength="14" oninput="mascaraCPF(this)" value="<?= htmlspecialchars($_POST['cpf'] ?? '') ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">CEP</label>
                                    <input type="text" class="form-control" name="cep" maxlength="9" oninput="mascaraCEP(this)" value="<?= htmlspecialchars($_POST['cep'] ?? '') ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Telefone</label>
                                    <input type="tel" class="form-control" name="telefone" maxlength="15" oninput="mascaraTelefone(this)" value="<?= htmlspecialchars($_POST['telefone'] ?? '') ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">E-mail</label>
                                    <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Data de nascimento</label>
                                    <input type="date" class="form-control" name="data_nascimento" value="<?= htmlspecialchars($_POST['data_nascimento'] ?? '') ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Logradouro</label>
                                    <input type="text" class="form-control" name="endereco" value="<?= htmlspecialchars($_POST['endereco'] ?? '') ?>" required>
                                </div>
                                <div class="row">
                                    <div class="col-4">
                                        <label class="form-label">Número</label>
                                        <input type="text" class="form-control" name="numero_casa" value="<?= htmlspecialchars($_POST['numero_casa'] ?? '') ?>" required>
                                    </div>
                                    <div class="col-8">
                                        <label class="form-label">Cidade / Estado</label>
                                        <input type="text" class="form-control" name="cidade_estado" value="<?= htmlspecialchars($_POST['cidade_estado'] ?? '') ?>" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if ($podeSelecionarPerfil): ?>
                            <div class="mb-3">
                                <label class="form-label">Perfil</label>
                                <select class="form-select" name="perfil">
                                    <?php foreach (['Administrador', 'Bibliotecario', 'Leitor'] as $perfilOption): ?>
                                        <option value="<?= htmlspecialchars($perfilOption) ?>" <?= (($_POST['perfil'] ?? 'Leitor') === $perfilOption) ? 'selected' : '' ?>><?= htmlspecialchars($perfilOption) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endif; ?>
                        <div class="row mt-3">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Senha</label>
                                <input type="password" class="form-control" name="senha" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Confirmar senha</label>
                                <input type="password" class="form-control" name="confirmar_senha" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-cadastro w-100">Cadastrar</button>
                        <div class="text-center mt-3">
                            Já possui uma conta?
                            <br>
                            <a href="<?= BASE_URL ?>/login.php" class="fw-semibold">Voltar para o login</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        function mascaraTelefone(input) {
            let v = input.value.replace(/\D/g, "");
            if (v.length > 0) v = "(" + v;
            if (v.length > 3) v = v.substring(0, 3) + ") " + v.substring(3);
            if (v.length > 10) v = v.substring(0, 10) + "-" + v.substring(10, 14);
            input.value = v;
        }

        function mascaraCPF(input) {
            let v = input.value.replace(/\D/g, "");
            if (v.length > 3) v = v.substring(0, 3) + "." + v.substring(3);
            if (v.length > 7) v = v.substring(0, 7) + "." + v.substring(7);
            if (v.length > 11) v = v.substring(0, 11) + "-" + v.substring(11, 13);
            input.value = v;
        }

        function mascaraCEP(input) {
            let v = input.value.replace(/\D/g, "");
            if (v.length > 5) v = v.substring(0, 5) + "-" + v.substring(5, 8);
            input.value = v;
        }
    </script>
</body>
</html>