<?php
require_once __DIR__ . "/../../config/constants.php";
?>

<!doctype html>
<html lang="pt-br" data-bs-theme="light">

<head>
    <title>Meus livros</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB"
        crossorigin="anonymous">

    <link rel="stylesheet" href="<?= CSS_URL ?>/historico_emprestimos.css">

</head>

<body>

    <?php include_once __DIR__ . "/../../include/header.php"; ?>

    <main class="historico-page">

        <?php include_once __DIR__ . "/../../include/livro.php"; ?>

        <div class="historico-titulo">
            <h1>Meus livros</h1>
            <p>Livros que você pegou emprestados</p>
        </div>

        <?php if (!empty($livros)): ?>

            <div class="carousel-livros">

                <button class="btn-seta esquerda" type="button">
                    &#10094;
                </button>

                <div class="scroll-livros">

                    <?php foreach ($livros as $livro): ?>

                        <div
                            class="livro-card"
                            onclick="window.location.href='<?= BASE_URL ?>/views/livro/livro_exibir.php?id=<?= $livro['id'] ?>'">

                            <img
                                src="<?= UPLOADS_URL ?>/capas_livros/<?= htmlspecialchars($livro['imagem']) ?>"
                                alt="<?= htmlspecialchars($livro['titulo']) ?>">

                            <div class="livro-info">

                                <h5>
                                    <?= htmlspecialchars($livro['titulo']) ?>
                                </h5>

                                <p>
                                    <?= htmlspecialchars($livro['autor']) ?>
                                </p>

                            </div>

                        </div>

                    <?php endforeach; ?>

                </div>

                <button class="btn-seta direita" type="button">
                    &#10095;
                </button>

            </div>

        <?php else: ?>

            <div class="container">
                <div class="sem-livros">
                    <h3>Nenhum livro emprestado</h3>
                    <p>Você ainda não possui livros emprestados.</p>
                </div>
            </div>

        <?php endif; ?>

    </main>

    <?php include_once __DIR__ . "/../../include/footer.php"; ?>

    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous">
    </script>

    <script>
        const scrollLivros = document.querySelector('.scroll-livros');
        const esquerda = document.querySelector('.btn-seta.esquerda');
        const direita = document.querySelector('.btn-seta.direita');

        if (scrollLivros && esquerda && direita) {

            esquerda.addEventListener('click', () => {
                scrollLivros.scrollBy({
                    left: -500,
                    behavior: 'smooth'
                });
            });

            direita.addEventListener('click', () => {
                scrollLivros.scrollBy({
                    left: 500,
                    behavior: 'smooth'
                });
            });
        }
    </script>

</body>

</html>