<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$perfilLogado = strtolower((string) ($_SESSION['perfil'] ?? $_SESSION['tipo'] ?? ''));
$dashboardVoltar = in_array($perfilLogado, ['admin', 'administrador'], true) ? BASE_URL . '/admin.php' : BASE_URL . '/bibliotecario.php';

$sql = 'SELECT u.*, e.logradouro, e.numero, e.cidade, e.estado, e.cep
        FROM usuario u
        LEFT JOIN endereco e ON e.id_usuario = u.id_usuario
        ORDER BY u.id_usuario DESC';

$result = $conn->query($sql);
$usuarios = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">
    <title>Usuários</title>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Usuários</h2>
                <small class="text-muted">Lista de usuários cadastrados</small>
            </div>
            <div class="d-flex gap-2">
                <a href="<?= BASE_URL ?>/views/usuario/usuario_cadastrar.php" class="btn btn-primary">Novo usuário</a>
                <a href="<?= htmlspecialchars($dashboardVoltar) ?>" class="btn btn-outline-secondary">Voltar</a>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Código</th>
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th>CPF</th>
                            <th>Perfil</th>
                            <th>Status</th>
                            <th class="text-center">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($usuarios)): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">Nenhum usuário cadastrado.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($usuarios as $usuario): ?>
                                <tr>
                                    <td><?= htmlspecialchars($usuario['id_usuario']) ?></td>
                                    <td><?= htmlspecialchars($usuario['nome_completo']) ?></td>
                                    <td><?= htmlspecialchars($usuario['email']) ?></td>
                                    <td><?= htmlspecialchars($usuario['cpf']) ?></td>
                                    <td><?= htmlspecialchars($usuario['perfil']) ?></td>
                                    <td><?= htmlspecialchars($usuario['status']) ?></td>
                                    <td class="text-center">
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?= BASE_URL ?>/views/usuario/usuario_editar.php?id=<?= (int)$usuario['id_usuario'] ?>" class="btn btn-warning">Editar</a>
                                            <a href="<?= BASE_URL ?>/views/usuario/usuario_excluir.php?id=<?= (int)$usuario['id_usuario'] ?>" class="btn btn-danger">Excluir</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>