<!doctype html>
<html lang="pt-br" data-bs-theme="light">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Minha Conta</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/CSS/usuario/usuario_contato.css">
    <link rel="stylesheet" href="../../assets/CSS/padrao.css">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>

<body>

    <?php require_once __DIR__ . '/../../include/header.php'; ?>

    <main class="perfil-page">

        <div class="perfil-card">

            <div class="perfil-header">
                <h1>Contato</h1>
            </div>

            <div class="perfil-body">

                <section class="perfil-content">

                    <h2 class="mb-4">Dados Pessoais</h2>

                    <form action="autenticacao.php" method="POST">

                        <div class="row g-4">

                            <div class="col-md-6">
                                <label class="form-label">Nome</label>
                                <input
                                    type="text"
                                    class="form-control"
                                    name="nome"
                                    placeholder="Seu nome completo"
                                    required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">E-mail</label>
                                <input
                                    type="email"
                                    class="form-control"
                                    name="email"
                                    placeholder="seu@email.com"
                                    required>
                            </div>

                            <div class="col-12">
                                <label class="form-label">Mensagem</label>
                                <textarea
                                    class="form-control"
                                    name="mensagem"
                                    placeholder="Mensagem"
                                    id="mensagem"
                                    rows="5"
                                    required></textarea>
                            </div>

                        </div>

                        <div class="text-end mt-4">
                            <button
                                type="submit"
                                class="btn btn-primary">
                                Enviar
                            </button>
                        </div>

                    </form>

                </section>

            </div>

        </div>

    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <?php require_once __DIR__ . '/../../include/footer.php'; ?>

</body>

</html>