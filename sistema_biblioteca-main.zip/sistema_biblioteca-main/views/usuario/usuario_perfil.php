<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

if (!isset($_SESSION['id_usuario'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$idUsuario = (int) $_SESSION['id_usuario'];
$mensagem = '';
$tipoMensagem = 'danger';

$stmt = $conn->prepare('SELECT u.*, e.logradouro, e.numero, e.complemento, e.bairro, e.cidade, e.estado, e.cep FROM usuario u LEFT JOIN endereco e ON e.id_usuario = u.id_usuario WHERE u.id_usuario = ?');
$stmt->bind_param('i', $idUsuario);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();

if (!$usuario) {
    session_destroy();
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? 'dados';

    if ($acao === 'dados') {
        $nome = trim($_POST['nome_completo'] ?? '');
        $telefone = trim($_POST['telefone'] ?? '');
        $cpf = preg_replace('/\D/', '', $_POST['cpf'] ?? '');
        $dataNascimento = $_POST['data_nascimento'] ?? null;
        $email = trim($_POST['email'] ?? '');

        if ($nome === '' || $email === '') {
            $mensagem = 'Nome e e-mail são obrigatórios.';
        } else {
            $stmt = $conn->prepare('UPDATE usuario SET nome_completo = ?, telefone = ?, cpf = ?, data_nascimento = ?, email = ? WHERE id_usuario = ?');
            $stmt->bind_param('sssssi', $nome, $telefone, $cpf, $dataNascimento, $email, $idUsuario);

            if ($stmt->execute()) {
                $_SESSION['nome_completo'] = $nome;
                $_SESSION['email'] = $email;
                $mensagem = 'Dados pessoais atualizados com sucesso.';
                $tipoMensagem = 'success';
                $usuario['nome_completo'] = $nome;
                $usuario['telefone'] = $telefone;
                $usuario['cpf'] = $cpf;
                $usuario['data_nascimento'] = $dataNascimento;
                $usuario['email'] = $email;
            } else {
                $mensagem = 'Erro ao atualizar os dados pessoais.';
            }
        }
    } elseif ($acao === 'endereco') {
        $logradouro = trim($_POST['logradouro'] ?? '');
        $numero = trim($_POST['numero'] ?? '');
        $bairro = trim($_POST['bairro'] ?? '');
        $cidade = trim($_POST['cidade'] ?? '');
        $estado = trim($_POST['estado'] ?? '');
        $cep = preg_replace('/\D/', '', $_POST['cep'] ?? '');
        $complemento = trim($_POST['complemento'] ?? '');

        $enderecoAtual = $conn->query('SELECT id_endereco FROM endereco WHERE id_usuario = ' . $idUsuario)->fetch_assoc();

        if ($enderecoAtual) {
            $stmt = $conn->prepare('UPDATE endereco SET logradouro = ?, numero = ?, complemento = ?, bairro = ?, cidade = ?, estado = ?, cep = ? WHERE id_usuario = ?');
            $stmt->bind_param('sssssssi', $logradouro, $numero, $complemento, $bairro, $cidade, $estado, $cep, $idUsuario);
        } else {
            $stmt = $conn->prepare('INSERT INTO endereco (id_usuario, logradouro, numero, complemento, bairro, cidade, estado, cep) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->bind_param('isssssss', $idUsuario, $logradouro, $numero, $complemento, $bairro, $cidade, $estado, $cep);
        }

        if ($stmt->execute()) {
            $mensagem = 'Endereço atualizado com sucesso.';
            $tipoMensagem = 'success';
            $usuario['logradouro'] = $logradouro;
            $usuario['numero'] = $numero;
            $usuario['bairro'] = $bairro;
            $usuario['cidade'] = $cidade;
            $usuario['estado'] = $estado;
            $usuario['cep'] = $cep;
            $usuario['complemento'] = $complemento;
        } else {
            $mensagem = 'Erro ao atualizar endereço.';
        }
    } elseif ($acao === 'senha') {
        $senhaAtual = $_POST['senha_atual'] ?? '';
        $novaSenha = $_POST['nova_senha'] ?? '';
        $confirmarSenha = $_POST['confirmar_senha'] ?? '';

        if ($novaSenha === '' || $confirmarSenha === '') {
            $mensagem = 'Informe a nova senha e a confirmação.';
        } elseif ($novaSenha !== $confirmarSenha) {
            $mensagem = 'A nova senha e a confirmação não conferem.';
        } elseif (!password_verify($senhaAtual, $usuario['senha'])) {
            $mensagem = 'A senha atual está incorreta.';
        } else {
            $senhaHash = password_hash($novaSenha, PASSWORD_DEFAULT);
            $stmt = $conn->prepare('UPDATE usuario SET senha = ? WHERE id_usuario = ?');
            $stmt->bind_param('si', $senhaHash, $idUsuario);

            if ($stmt->execute()) {
                $mensagem = 'Senha alterada com sucesso.';
                $tipoMensagem = 'success';
            } else {
                $mensagem = 'Erro ao alterar a senha.';
            }
        }
    } elseif ($acao === 'excluir') {
        $stmt = $conn->prepare('UPDATE usuario SET status = ? WHERE id_usuario = ?');
        $status = 'Inativo';
        $stmt->bind_param('si', $status, $idUsuario);

        if ($stmt->execute()) {
            session_destroy();
            header('Location: ' . BASE_URL . '/login.php?status=inativo');
            exit;
        }

        $mensagem = 'Erro ao inativar a conta.';
    }
}
?>
<!doctype html>
<html lang="pt-br" data-bs-theme="light">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Minha Conta</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/CSS/usuario/usuario_perfil.css">
    <link rel="stylesheet" href="../../assets/CSS/padrao.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>

<body>
    <?php require_once __DIR__ . '/../../include/header.php'; ?>

    <main class="perfil-page">
        <div class="perfil-card">
            <div class="perfil-header">
                <h1>Minha Conta</h1>
                <p>Gerencie suas informações pessoais.</p>
            </div>

            <?php if ($mensagem !== ''): ?>
                <div class="alert alert-<?= htmlspecialchars($tipoMensagem) ?> mx-4 mt-3 mb-0"><?= htmlspecialchars($mensagem) ?></div>
            <?php endif; ?>

            <div class="perfil-body">
                <aside class="perfil-menu">
                    <button class="active" type="button" data-target="perfil"><i class="fa-solid fa-user me-2"></i>Perfil</button>
                    <button type="button" data-target="endereco"><i class="fa-solid fa-location-dot me-2"></i>Endereço</button>
                    <button type="button" data-target="seguranca"><i class="fa-solid fa-lock me-2"></i>Segurança</button>
                </aside>

                <section class="perfil-content">
                    <div class="section-panel active" data-section="perfil">
                        <form method="POST">
                            <input type="hidden" name="acao" value="dados">
                            <h2 class="mb-4">Dados Pessoais</h2>
                            <div class="row g-4">
                                <div class="col-md-6">
                                    <label class="form-label">Nome</label>
                                    <input type="text" class="form-control" name="nome_completo" value="<?= htmlspecialchars($_POST['nome_completo'] ?? $usuario['nome_completo']) ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Telefone</label>
                                    <input type="tel" class="form-control" name="telefone" value="<?= htmlspecialchars($_POST['telefone'] ?? ($usuario['telefone'] ?? '')) ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">CPF</label>
                                    <input type="text" class="form-control" name="cpf" value="<?= htmlspecialchars($_POST['cpf'] ?? ($usuario['cpf'] ?? '')) ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Data de nascimento</label>
                                    <input type="date" class="form-control" name="data_nascimento" value="<?= htmlspecialchars($_POST['data_nascimento'] ?? ($usuario['data_nascimento'] ?? '')) ?>">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">E-mail</label>
                                    <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($_POST['email'] ?? $usuario['email']) ?>" required>
                                </div>
                            </div>
                            <div class="text-end mt-4">
                                <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                            </div>
                        </form>
                    </div>

                    <div class="section-panel" data-section="endereco">
                        <form method="POST">
                            <input type="hidden" name="acao" value="endereco">
                            <h2 class="mb-4">Endereço</h2>
                            <div class="row g-4">
                                <div class="col-md-3">
                                    <label class="form-label">CEP</label>
                                    <input type="text" class="form-control" name="cep" value="<?= htmlspecialchars($_POST['cep'] ?? ($usuario['cep'] ?? '')) ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Estado</label>
                                    <input type="text" class="form-control" name="estado" value="<?= htmlspecialchars($_POST['estado'] ?? ($usuario['estado'] ?? '')) ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Cidade</label>
                                    <input type="text" class="form-control" name="cidade" value="<?= htmlspecialchars($_POST['cidade'] ?? ($usuario['cidade'] ?? '')) ?>">
                                </div>
                                <div class="col-md-8">
                                    <label class="form-label">Logradouro</label>
                                    <input type="text" class="form-control" name="logradouro" value="<?= htmlspecialchars($_POST['logradouro'] ?? ($usuario['logradouro'] ?? '')) ?>">
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">Número</label>
                                    <input type="text" class="form-control" name="numero" value="<?= htmlspecialchars($_POST['numero'] ?? ($usuario['numero'] ?? '')) ?>">
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">Complemento</label>
                                    <input type="text" class="form-control" name="complemento" value="<?= htmlspecialchars($_POST['complemento'] ?? ($usuario['complemento'] ?? '')) ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Bairro</label>
                                    <input type="text" class="form-control" name="bairro" value="<?= htmlspecialchars($_POST['bairro'] ?? ($usuario['bairro'] ?? '')) ?>">
                                </div>
                            </div>
                            <div class="text-end mt-4">
                                <button type="submit" class="btn btn-success">Salvar Endereço</button>
                            </div>
                        </form>
                    </div>

                    <div class="section-panel" data-section="seguranca">
                        <form method="POST">
                            <input type="hidden" name="acao" value="senha">
                            <h2 class="mb-4">Segurança</h2>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label">Senha atual</label>
                                    <input type="password" class="form-control" name="senha_atual" required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Nova senha</label>
                                    <input type="password" class="form-control" name="nova_senha" required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Confirmar nova senha</label>
                                    <input type="password" class="form-control" name="confirmar_senha" required>
                                </div>
                            </div>
                            <div class="text-end mt-4">
                                <button type="submit" class="btn btn-dark">Alterar Senha</button>
                            </div>
                        </form>

                        <div class="delete-box mt-4">
                            <h2>Inativar Conta</h2>
                            <p>Esta ação mantém seus dados no sistema, mas a conta passa a ficar inativa para login.</p>
                            <form method="POST" onsubmit="return confirm('Deseja realmente inativar sua conta?')">
                                <input type="hidden" name="acao" value="excluir">
                                <button type="submit" class="btn btn-danger">Inativar Conta</button>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const menuButtons = document.querySelectorAll('.perfil-menu button');
        const panels = document.querySelectorAll('.section-panel');

        menuButtons.forEach((button) => {
            button.addEventListener('click', () => {
                const target = button.dataset.target;

                menuButtons.forEach((item) => item.classList.toggle('active', item === button));
                panels.forEach((panel) => {
                    panel.classList.toggle('active', panel.dataset.section === target);
                });
            });
        });
    </script>
    <?php require_once __DIR__ . '/../../include/footer.php'; ?>
</body>
</html>