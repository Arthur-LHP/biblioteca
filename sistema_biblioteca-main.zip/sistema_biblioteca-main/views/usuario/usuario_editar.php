<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../config/conexao.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$mensagem = '';
$perfilLogado = strtolower((string) ($_SESSION['perfil'] ?? $_SESSION['tipo'] ?? ''));
$podeEditarPerfil = in_array($perfilLogado, ['admin', 'administrador'], true);

if ($id <= 0) {
    header('Location: ' . BASE_URL . '/views/usuario/usuario_listar.php');
    exit;
}

$stmt = $conn->prepare('SELECT u.*, e.logradouro, e.numero, e.cidade, e.estado, e.cep FROM usuario u LEFT JOIN endereco e ON e.id_usuario = u.id_usuario WHERE u.id_usuario = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();

if (!$usuario) {
    header('Location: ' . BASE_URL . '/views/usuario/usuario_listar.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome_completo_usuario'] ?? '');
    $cpf = preg_replace('/\D/', '', $_POST['cpf'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $dataNascimento = $_POST['data_nascimento'] ?? null;
    $perfil = $podeEditarPerfil ? ($_POST['perfil'] ?? ($usuario['perfil'] ?? 'Leitor')) : ($usuario['perfil'] ?? 'Leitor');
    $status = $_POST['status'] ?? 'Ativo';
    $logradouro = trim($_POST['logradouro'] ?? '');
    $numero = trim($_POST['numero_casa'] ?? '');
    $cidade = trim($_POST['cidade'] ?? '');
    $estado = trim($_POST['estado'] ?? '');
    $cep = preg_replace('/\D/', '', $_POST['cep'] ?? '');

    if ($nome === '' || $email === '') {
        $mensagem = 'Preencha nome e e-mail.';
    } else {
        $stmt = $conn->prepare('UPDATE usuario SET nome_completo = ?, data_nascimento = ?, telefone = ?, cpf = ?, email = ?, perfil = ?, status = ? WHERE id_usuario = ?');
        $stmt->bind_param('sssssssi', $nome, $dataNascimento, $telefone, $cpf, $email, $perfil, $status, $id);

        if ($stmt->execute()) {
            $stmtEndereco = $conn->prepare('SELECT id_endereco FROM endereco WHERE id_usuario = ?');
            $stmtEndereco->bind_param('i', $id);
            $stmtEndereco->execute();
            $endereco = $stmtEndereco->get_result()->fetch_assoc();

            if ($endereco) {
                $stmtEnderecoUpdate = $conn->prepare('UPDATE endereco SET logradouro = ?, numero = ?, cidade = ?, estado = ?, cep = ? WHERE id_usuario = ?');
                $stmtEnderecoUpdate->bind_param('sssssi', $logradouro, $numero, $cidade, $estado, $cep, $id);
                $stmtEnderecoUpdate->execute();
            } else {
                $stmtEnderecoInsert = $conn->prepare('INSERT INTO endereco (id_usuario, logradouro, numero, complemento, bairro, cidade, estado, cep) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
                $complemento = '';
                $bairro = '';
                $stmtEnderecoInsert->bind_param('isssssss', $id, $logradouro, $numero, $complemento, $bairro, $cidade, $estado, $cep);
                $stmtEnderecoInsert->execute();
            }

            header('Location: ' . BASE_URL . '/views/usuario/usuario_listar.php');
            exit;
        }

        $mensagem = 'Erro ao atualizar usuário.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Editar Usuário</title>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h3 class="mb-0">Editar Usuário</h3>
                            <a href="<?= BASE_URL ?>/views/usuario/usuario_listar.php" class="btn btn-outline-secondary btn-sm">Voltar</a>
                        </div>
                        <?php if ($mensagem !== ''): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($mensagem) ?></div>
                        <?php endif; ?>
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Nome completo</label>
                                    <input type="text" class="form-control" name="nome_completo_usuario" value="<?= htmlspecialchars($_POST['nome_completo_usuario'] ?? $usuario['nome_completo']) ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">CPF</label>
                                    <input type="text" class="form-control" name="cpf" value="<?= htmlspecialchars($_POST['cpf'] ?? $usuario['cpf']) ?>" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">E-mail</label>
                                    <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($_POST['email'] ?? $usuario['email']) ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Telefone</label>
                                    <input type="text" class="form-control" name="telefone" value="<?= htmlspecialchars($_POST['telefone'] ?? $usuario['telefone']) ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Data de nascimento</label>
                                    <input type="date" class="form-control" name="data_nascimento" value="<?= htmlspecialchars($_POST['data_nascimento'] ?? $usuario['data_nascimento']) ?>">
                                </div>
                                <?php if ($podeEditarPerfil): ?>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Perfil</label>
                                        <select class="form-select" name="perfil">
                                            <?php foreach (['Administrador', 'Bibliotecario', 'Leitor'] as $perfilOption): ?>
                                                <option value="<?= htmlspecialchars($perfilOption) ?>" <?= (($_POST['perfil'] ?? $usuario['perfil']) === $perfilOption) ? 'selected' : '' ?>><?= htmlspecialchars($perfilOption) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                <?php else: ?>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Perfil</label>
                                        <input type="text" class="form-control" value="<?= htmlspecialchars($usuario['perfil'] ?? 'Leitor') ?>" readonly>
                                    </div>
                                <?php endif; ?>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Status</label>
                                    <select class="form-select" name="status">
                                        <?php foreach (['Ativo', 'Inativo', 'Bloqueado'] as $statusOption): ?>
                                            <option value="<?= $statusOption ?>" <?= ($_POST['status'] ?? $usuario['status']) === $statusOption ? 'selected' : '' ?>><?= $statusOption ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Logradouro</label>
                                    <input type="text" class="form-control" name="logradouro" value="<?= htmlspecialchars($_POST['logradouro'] ?? ($usuario['logradouro'] ?? '')) ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Número</label>
                                    <input type="text" class="form-control" name="numero_casa" value="<?= htmlspecialchars($_POST['numero_casa'] ?? ($usuario['numero'] ?? '')) ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">CEP</label>
                                    <input type="text" class="form-control" name="cep" value="<?= htmlspecialchars($_POST['cep'] ?? ($usuario['cep'] ?? '')) ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Cidade</label>
                                    <input type="text" class="form-control" name="cidade" value="<?= htmlspecialchars($_POST['cidade'] ?? ($usuario['cidade'] ?? '')) ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Estado</label>
                                    <input type="text" class="form-control" name="estado" value="<?= htmlspecialchars($_POST['estado'] ?? ($usuario['estado'] ?? '')) ?>">
                                </div>
                            </div>
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">Salvar</button>
                                <a href="<?= BASE_URL ?>/views/usuario/usuario_listar.php" class="btn btn-outline-secondary">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>