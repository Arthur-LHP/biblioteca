<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/config/constants.php';
require_once __DIR__ . '/config/conexao.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $email = trim((string) ($_POST["email"] ?? ""));
  $senha = (string) ($_POST["senha"] ?? "");

  $sql = "SELECT id_usuario, nome_completo, email, senha, perfil, status
          FROM usuario
          WHERE email = ? AND status = 'Ativo'
          LIMIT 1";

  $stmt = $conn->prepare($sql);

  if (!$stmt) {
    die("Erro na preparação da consulta: " . $conn->error);
  }

  $stmt->bind_param("s", $email);
  $stmt->execute();

  $resultado = $stmt->get_result();
  $usuario = $resultado->fetch_assoc();

  if ($usuario && password_verify($senha, $usuario["senha"])) {
    $perfilNormalizado = strtolower(trim((string) $usuario["perfil"]));

    $_SESSION["id_usuario"] = (int) $usuario["id_usuario"];
    $_SESSION["nome_completo"] = $usuario["nome_completo"];
    $_SESSION["email"] = $usuario["email"];
    $_SESSION["perfil"] = $perfilNormalizado;
    $_SESSION["tipo"] = $perfilNormalizado === "administrador" ? "admin" : $perfilNormalizado;

    if ($perfilNormalizado === "bibliotecario") {
      header("Location: " . BASE_URL . "/bibliotecario.php");
    } elseif ($perfilNormalizado === "administrador") {
      header("Location: " . BASE_URL . "/admin.php");
    } else {
      header("Location: " . BASE_URL . "/index.php");
    }

    exit;
  }

  header("Location: " . BASE_URL . "/login.php?erro=login");
  exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br" data-bs-theme="light">

<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Login - Biblioteca</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">

  <link rel="stylesheet" href="assets/CSS/login.css">

</head>

<body>

  <div class="container-fluid container-login">
    <div class="row h-100">
      <div class="col-lg-7 lado-imagem">
        <img src="assets/img/mulher_lendo.svg"
          alt="Biblioteca"
          class="img-fluid">
      </div>

      <div class="col-lg-5 lado-form">
        <div class="login-card">
          <div class="logo">
            <span class="azul">BIBLIO</span><span class="amarelo">TECA</span>
          </div>

          <h3 class="text-center">
            Bem-vindo
          </h3>

          <?php if (isset($_GET["erro"]) && $_GET["erro"] === "login"): ?>

            <div class="alert alert-danger text-center" role="alert">
              E-mail ou senha incorretos.
            </div>

          <?php endif; ?>

          <form method="POST">
            <div class="mb-3">
              <label class="form-label">
                E-mail
              </label>
              <input
                type="email"
                name="email"
                class="form-control"
                placeholder="Digite seu e-mail"
                required>
            </div>

            <div class="mb-3">
              <label class="form-label">
                Senha
              </label>
              <input type="password" name="senha" class="form-control" placeholder="Digite sua senha" required>
            </div>

            <div class="text-end">
              <a href="recuperar_senha.php">
                Esqueci minha senha
              </a>
            </div>


            <button type="submit" class="btn btn-login w-100">
              Entrar
            </button>
          </form>

          <hr>

          <div class="text-center">
            Não possui uma conta?
            <br>
            <a href="views/usuario/usuario_cadastrar.php" class="fw-semibold">
              Cadastre-se
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>




  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>