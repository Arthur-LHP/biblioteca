<!doctype html>
<html lang="pt-br" data-bs-theme="light">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Biblioteca Início</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <link rel="stylesheet" href="assets/CSS/style.css">
    <link rel="stylesheet" href="assets/CSS/padrao.css">
</head>

<body>

    <?php require_once __DIR__ . '/include/header.php'; ?>

    <main>

        <?php require_once __DIR__ . '/include/livro.php'; ?>

        <?php

        $livrosPorCategoria = [];
        foreach ($livros as $livro) {
            $categoriasDoLivro = array_filter(array_map('trim', explode(',', $livro['categorias'])));
            if ($categoriasDoLivro === []) {
                $categoriasDoLivro = ['Sem categoria'];
            }

            foreach ($categoriasDoLivro as $categoriaDoLivro) {
                $livrosPorCategoria[$categoriaDoLivro][] = $livro;
            }
        }

        $categorias = array_keys($livrosPorCategoria);
        $livrosRecomendados = array_slice($livros, 0, 6);
        if ($livrosRecomendados !== []) {
            $livrosPorCategoria = array_merge(
                ['Recomendados' => $livrosRecomendados],
                $livrosPorCategoria
            );
            $categorias = array_keys($livrosPorCategoria);
        }

        $possuiConteudoSensivel = in_array(true, array_column($livros, 'sensivel'), true);

        ?>

        <?php foreach ($categorias as $categoria): ?>

            <section class="categoria-livros">

                <div class="container">

                    <div class="categoria-titulo">
                        <h2><?= htmlspecialchars($categoria) ?></h2>
                    </div>

                    <div class="carousel-livros">

                        <button
                            class="btn-seta esquerda"
                            type="button">
                            &#10094;
                        </button>

                        <div class="scroll-livros">

                            <?php foreach ($livrosPorCategoria[$categoria] as $livro): ?>

                                <div
                                    class="livro-card<?= $livro['sensivel'] ? ' livro-card-sensivel' : '' ?>"
                                    data-sensitive="<?= $livro['sensivel'] ? 'true' : 'false' ?>"
                                    role="link"
                                    tabindex="0"
                                    onclick="abrirLivro(this, 'views/livro/livro_exibir.php?id=<?= $livro['id'] ?>')"
                                    onkeydown="if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); abrirLivro(this, 'views/livro/livro_exibir.php?id=<?= $livro['id'] ?>'); }">

                                    <img
                                        src="uploads/capas_livros/<?= htmlspecialchars($livro['imagem']) ?>"
                                        alt="<?= htmlspecialchars($livro['titulo']) ?>">

                                    <div class="livro-info">

                                        <h5>
                                            <?= htmlspecialchars($livro['titulo']) ?>
                                        </h5>

                                        <p>
                                            <?= htmlspecialchars($livro['autor']) ?>
                                        </p>
                                        <small>Classificação: <?= htmlspecialchars($livro['classificacao_indicativa']) ?></small>

                                    </div>

                                    <?php if ($livro['sensivel']): ?>
                                        <div class="livro-aviso-sensivel">Conteúdo sensível<br><small>Requer consentimento</small></div>
                                    <?php endif; ?>

                                </div>

                            <?php endforeach; ?>

                        </div>

                        <button
                            class="btn-seta direita"
                            type="button">
                            &#10095;
                        </button>

                    </div>

                </div>

            </section>

        <?php endforeach; ?>

    </main>

    <?php if ($possuiConteudoSensivel): ?>
        <div class="modal fade" id="modalConteudoSensivel" tabindex="-1" aria-labelledby="modalConteudoSensivelTitulo" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalConteudoSensivelTitulo">Aviso de conteúdo sensível</h5>
                    </div>
                    <div class="modal-body">
                        Alguns livros possuem classificação indicativa para maiores de 16 ou 18 anos ou sinalização de conteúdo adulto.
                        Você deseja visualizar esses livros e declara estar ciente dessa classificação?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Não, ocultar</button>
                        <button type="button" class="btn btn-primary" id="aceitarConteudoSensivel">Sim, estou ciente</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php require_once __DIR__ . '/include/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let consentimentoSensivel = sessionStorage.getItem("consentimentoConteudoSensivel") === "true";

        function atualizarConteudoSensivel() {
            document.querySelectorAll("[data-sensitive='true']").forEach(card => {
                card.classList.toggle("livro-card-bloqueado", !consentimentoSensivel);
            });
        }

        function abrirLivro(card, url) {
            if (card.dataset.sensitive === "true" && !consentimentoSensivel) {
                const modalElement = document.getElementById("modalConteudoSensivel");
                if (modalElement) bootstrap.Modal.getOrCreateInstance(modalElement).show();
                return;
            }
            window.location.href = url;
        }

        atualizarConteudoSensivel();

        const modalConteudoSensivel = document.getElementById("modalConteudoSensivel");
        const aceitarConteudoSensivel = document.getElementById("aceitarConteudoSensivel");
        if (aceitarConteudoSensivel) {
            aceitarConteudoSensivel.addEventListener("click", () => {
                consentimentoSensivel = true;
                sessionStorage.setItem("consentimentoConteudoSensivel", "true");
                atualizarConteudoSensivel();
                bootstrap.Modal.getOrCreateInstance(modalConteudoSensivel).hide();
            });
        }

        if (modalConteudoSensivel && !consentimentoSensivel) {
            bootstrap.Modal.getOrCreateInstance(modalConteudoSensivel).show();
        }

        document.querySelectorAll(".carousel-livros").forEach(carrossel => {

            const lista = carrossel.querySelector(".scroll-livros");
            const card = lista.querySelector(".livro-card");

            if (!card) return;

            const gap = 18;
            const passo = (card.offsetWidth + gap) * 6;

            carrossel.querySelector(".direita").addEventListener("click", () => {

                lista.scrollBy({
                    left: passo,
                    behavior: "smooth"
                });

            });

            carrossel.querySelector(".esquerda").addEventListener("click", () => {

                lista.scrollBy({
                    left: -passo,
                    behavior: "smooth"
                });

            });

        });
    </script>

</body>

</html>