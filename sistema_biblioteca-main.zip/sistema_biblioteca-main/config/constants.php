<?php

$documentRoot = realpath($_SERVER['DOCUMENT_ROOT']);
$projectRoot = realpath(dirname(__DIR__));

if ($documentRoot !== false && $projectRoot !== false) {
    $relativePath = str_replace('\\', '/', str_replace($documentRoot, '', $projectRoot));

    $relativePath = '/' . trim($relativePath, '/');

    if ($relativePath === '/') {
        $relativePath = '';
    }
} else {
    $relativePath = '';
}

define('BASE_URL', $relativePath);

define('SITE_NAME', 'Biblioteca');

define('ASSETS_URL', BASE_URL . '/assets');

define('CSS_URL', ASSETS_URL . '/CSS');

define('JS_URL', ASSETS_URL . '/JS');

define('IMG_URL', ASSETS_URL . '/img');

define('UPLOADS_URL', BASE_URL . '/uploads');

define('LIVROS_URL', UPLOADS_URL . '/capas_livros');

define('ROOT_PATH', dirname(__DIR__));