<?php

$conn = new mysqli("sql101.infinityfree.com", "if0_42271388", "zlUFJRBDqVfK1", "if0_42271388_biblioteca");
/* $conn = new mysqli("localhost", "root", "", "biblioteca"); */

if ($conn->connect_error) {
    die("Erro ao conectar ao banco de dados: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
date_default_timezone_set("America/Sao_Paulo");
