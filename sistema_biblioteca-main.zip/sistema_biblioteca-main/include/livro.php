<?php
require_once __DIR__ . '/../config/conexao.php';

$livros = [];

if (isset($conn) && $conn instanceof mysqli) {
    $sql = "SELECT l.id_livro AS id,
                    l.titulo,
                    l.imagem_capa AS imagem,
                    l.descricao AS sinopse,
                    GROUP_CONCAT(DISTINCT a.nome_autor ORDER BY a.nome_autor SEPARATOR ', ') AS autor,
                    GROUP_CONCAT(DISTINCT c.nome_categoria ORDER BY c.nome_categoria SEPARATOR ', ') AS categorias,
                    l.classificacao_indicativa,
                    l.status
            FROM livro l
            LEFT JOIN livro_autor la ON la.id_livro = l.id_livro
            LEFT JOIN autor a ON a.id_autor = la.id_autor
            LEFT JOIN livro_categoria lc ON lc.id_livro = l.id_livro
            LEFT JOIN categoria c ON c.id_categoria = lc.id_categoria AND c.status = 'Ativo'
            WHERE l.status = 'Ativo' AND COALESCE(l.imagem_capa, '') <> ''
            GROUP BY l.id_livro, l.titulo, l.imagem_capa, l.descricao, l.classificacao_indicativa, l.status
            ORDER BY l.titulo ASC";

    $resultado = $conn->query($sql);

    if ($resultado && $resultado->num_rows > 0) {
        while ($livro = $resultado->fetch_assoc()) {
            $livros[] = [
                'id' => (int) $livro['id'],
                'imagem' => $livro['imagem'],
                'titulo' => $livro['titulo'],
                'autor' => $livro['autor'] ?: 'Autor não informado',
                'categorias' => $livro['categorias'] ?: 'Sem categoria',
                'classificacao_indicativa' => $livro['classificacao_indicativa'] ?: 'Não informada',
                'sensivel' => preg_match('/(^|[^0-9])(16|18)([^0-9]|$)|adult/i', (string) $livro['classificacao_indicativa']) === 1,
                'sinopse' => !empty($livro['sinopse']) ? $livro['sinopse'] : 'Livro disponível no catálogo da biblioteca.',
                'disponivel' => true,
            ];
        }
    }
}
?>