<footer class="site-footer">
    <div class="container text-center">
        <p class="mb-1">&copy; 2026 Meu Site. Todos os direitos reservados.</p>

        <small>
            Desenvolvido por
            <a href="#" class="footer-link">Matheus Ramalho</a>
            e
            <a href="#" class="footer-link">Arthur Terra</a>
        </small>
    </div>
</footer>