<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/constants.php';

$usuarioLogado = !empty($_SESSION['id_usuario']);
$nomeUsuario = isset($_SESSION['nome_completo']) ? trim((string) $_SESSION['nome_completo'] ) : 'Usuário';
$perfil = strtolower((string) ($_SESSION['perfil'] ?? $_SESSION['tipo'] ?? ''));

$opcoesMenu = [
    ['label' => 'Minha Conta', 'url' => BASE_URL . '/views/usuario/usuario_perfil.php'],
    ['label' => 'Meus Livros', 'url' => BASE_URL . '/views/usuario/historico_emprestimos.php'],
    ['label' => 'Catálogo', 'url' => BASE_URL . '/views/livro/catalogo_livros.php'],
    ['label' => 'Contato', 'url' => BASE_URL . '/views/usuario/usuario_contato.php'],
];

if (in_array($perfil, ['bibliotecario', 'admin', 'administrador'], true)) {
    $opcoesMenu = [
        ['label' => 'Dashboard', 'url' => BASE_URL . ($perfil === 'bibliotecario' ? '/bibliotecario.php' : '/admin.php')],
        ['label' => 'Usuários', 'url' => BASE_URL . '/views/usuario/usuario_listar.php'],
        ['label' => 'Livros', 'url' => BASE_URL . '/views/livro/livro_listar.php'],
        ['label' => 'Autores', 'url' => BASE_URL . '/views/autor/autor_listar.php'],
        ['label' => 'Categorias', 'url' => BASE_URL . '/views/categoria/categoria_listar.php'],
        ['label' => 'Editoras', 'url' => BASE_URL . '/views/editora/editora_listar.php'],
    ];
}
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= CSS_URL ?>/include.css" rel="stylesheet">
</head>

<header class="site-header">
    <nav class="navbar navbar-expand-lg site-navbar">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold fs-3" href="<?= BASE_URL ?>/index.php">
                <span class="logo-blue">BIBLIO</span><span class="logo-yellow">TECA</span>
            </a>

            <div class="d-flex align-items-center">
                <?php if ($usuarioLogado): ?>
                    <span class="welcome-message me-3">Olá, <?= htmlspecialchars($nomeUsuario) ?></span>
                <?php else: ?>
                    <a href="<?= BASE_URL ?>/login.php" class="btn btn-acessar fw-bold me-3 px-4">ACESSE</a>
                <?php endif; ?>

                <a href="<?= BASE_URL ?>/index.php" class="header-icon me-3 fs-5">
                    <i class="bi bi-house-door-fill"></i>
                </a>

                <a href="#" class="header-icon me-3 fs-5">
                    <i class="bi bi-question-circle"></i>
                </a>

                <form class="header-search me-3" method="GET" action="<?= BASE_URL ?>/views/livro/catalogo_livros.php">
                    <div class="input-group">
                        <input type="search" name="busca" class="form-control" placeholder="BUSCAR">
                        <button class="btn" type="submit">
                            <i class="bi bi-search"></i>
                        </button>
                    </div>
                </form>

                <button class="btn menu-button fs-3 border-0" data-bs-toggle="offcanvas" data-bs-target="#menuLateral">
                    <i class="bi bi-list"></i>
                </button>
            </div>
        </div>
    </nav>

    <div class="offcanvas offcanvas-end" tabindex="-1" id="menuLateral">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">Menu</h5>
            <button class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>

        <div class="offcanvas-body">
            <ul class="navbar-nav">
                <?php foreach ($opcoesMenu as $item): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= htmlspecialchars($item['url']) ?>"><?= htmlspecialchars($item['label']) ?></a>
                    </li>
                <?php endforeach; ?>

                <hr>

                <li class="nav-item">
                    <a class="nav-link text-danger" href="<?= BASE_URL ?>/logout.php">Sair</a>
                </li>
            </ul>
        </div>
    </div>
</header>