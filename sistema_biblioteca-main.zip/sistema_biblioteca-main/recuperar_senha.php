<?php

require_once __DIR__ . '/config/constants.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$mensagem = "";
$erro = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");

    if (empty($email)) {

        $erro = "Digite seu e-mail.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $erro = "Digite um e-mail válido.";
    } else {



        $mensagem = "Se o e-mail estiver cadastrado, você receberá um link para redefinir sua senha.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br" data-bs-theme="light">

<head>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Esqueci minha senha - Biblioteca</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <link rel="stylesheet" href="<?= CSS_URL ?>/usuario/esqueci_senha.css">

</head>

<body>

    <div class="container-fluid container-recuperacao">

        <div class="row h-100">

            <div class="col-lg-7 lado-imagem">

                <img
                    src="assets/img/mulher_lendo.svg"
                    alt="Biblioteca"
                    class="img-fluid">

            </div>


            <div class="col-lg-5 lado-form">

                <div class="recuperacao-card">

                    <div class="logo">

                        <span class="azul">BIBLIO</span><span class="amarelo">TECA</span>

                    </div>


                    <h3 class="text-center">
                        Recuperar senha
                    </h3>


                    <p class="descricao text-center">

                        Informe o e-mail cadastrado para receber
                        as instruções de recuperação da sua senha.

                    </p>


                    <?php if (!empty($erro)): ?>

                        <div class="alert alert-danger" role="alert">

                            <?= htmlspecialchars($erro) ?>

                        </div>

                    <?php endif; ?>


                    <?php if (!empty($mensagem)): ?>

                        <div class="alert alert-success" role="alert">

                            <?= htmlspecialchars($mensagem) ?>

                        </div>

                    <?php endif; ?>


                    <form action="login.php" method="POST">

                        <div class="mb-3">

                            <label
                                for="email"
                                class="form-label">

                                E-mail

                            </label>

                            <input
                                type="email"
                                id="email"
                                name="email"
                                class="form-control"
                                placeholder="Digite seu e-mail"
                                required>

                        </div>


                        <button
                            type="submit"
                            class="btn btn-recuperacao w-100">

                            Enviar link de recuperação

                        </button>

                    </form>


                    <hr>


                    <div class="text-center">

                        <a href="login.php" class="voltar-login">

                            ← Voltar para o login

                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js">
    </script>

</body>

</html>