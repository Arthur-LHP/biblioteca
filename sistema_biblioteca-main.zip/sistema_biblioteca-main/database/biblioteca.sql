
DROP TABLE IF EXISTS pagamento_multa;
DROP TABLE IF EXISTS multa;
DROP TABLE IF EXISTS emprestimo;
DROP TABLE IF EXISTS reserva;
DROP TABLE IF EXISTS solicitacao_emprestimo;
DROP TABLE IF EXISTS livro_categoria;
DROP TABLE IF EXISTS livro_autor;
DROP TABLE IF EXISTS livro;
DROP TABLE IF EXISTS categoria;
DROP TABLE IF EXISTS autor;
DROP TABLE IF EXISTS editora;
DROP TABLE IF EXISTS notificacao;
DROP TABLE IF EXISTS relatorio;
DROP TABLE IF EXISTS endereco;
DROP TABLE IF EXISTS usuario;

CREATE TABLE usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome_completo VARCHAR(150) NOT NULL,
    data_nascimento DATE,
    telefone VARCHAR(20),
    cpf VARCHAR(14) UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    perfil ENUM('Administrador','Bibliotecario','Leitor') NOT NULL DEFAULT 'Leitor',
    status ENUM('Ativo','Inativo','Bloqueado') DEFAULT 'Ativo',
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE endereco (
    id_endereco INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    logradouro VARCHAR(200),
    numero VARCHAR(20),
    complemento VARCHAR(100),
    bairro VARCHAR(100),
    cidade VARCHAR(100),
    estado VARCHAR(2),
    cep VARCHAR(10),
    CONSTRAINT fk_endereco_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario) ON DELETE CASCADE
);

CREATE TABLE editora (
    id_editora INT AUTO_INCREMENT PRIMARY KEY,
    nome_editora VARCHAR(150) NOT NULL UNIQUE,
    telefone VARCHAR(20),
    email VARCHAR(150),
    site VARCHAR(255),
    status ENUM('Ativo','Inativo') NOT NULL DEFAULT 'Ativo',
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE autor (
    id_autor INT AUTO_INCREMENT PRIMARY KEY,
    nome_autor VARCHAR(150) NOT NULL,
    data_nascimento DATE,
    data_morte DATE,
    status ENUM('Ativo','Inativo') NOT NULL DEFAULT 'Ativo',
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_autor_nome (nome_autor)
);

CREATE TABLE categoria (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nome_categoria VARCHAR(100) NOT NULL,
    descricao TEXT,
    status ENUM('Ativo','Inativo') NOT NULL DEFAULT 'Ativo',
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_categoria_nome (nome_categoria)
);

CREATE TABLE livro (
    id_livro INT AUTO_INCREMENT PRIMARY KEY,
    id_editora INT,
    titulo VARCHAR(200) NOT NULL,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    classificacao_indicativa VARCHAR(20),
    quantidade_total INT NOT NULL DEFAULT 0,
    quantidade_disponivel INT NOT NULL DEFAULT 0,
    imagem_capa VARCHAR(255) DEFAULT NULL,
    descricao TEXT,
    status ENUM('Ativo','Inativo') NOT NULL DEFAULT 'Ativo',
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_livro_quantidade_total CHECK (quantidade_total >= 0),
    CONSTRAINT chk_livro_quantidade_disponivel CHECK (quantidade_disponivel >= 0 AND quantidade_disponivel <= quantidade_total),
    CONSTRAINT fk_livro_editora FOREIGN KEY (id_editora) REFERENCES editora(id_editora) ON DELETE SET NULL
);

CREATE TABLE livro_autor (
    id_livro_autor INT AUTO_INCREMENT PRIMARY KEY,
    id_livro INT NOT NULL,
    id_autor INT NOT NULL,
    UNIQUE (id_livro, id_autor),
    CONSTRAINT fk_livro_autor_livro FOREIGN KEY (id_livro) REFERENCES livro(id_livro) ON DELETE CASCADE,
    CONSTRAINT fk_livro_autor_autor FOREIGN KEY (id_autor) REFERENCES autor(id_autor) ON DELETE RESTRICT
);

CREATE TABLE livro_categoria (
    id_livro_categoria INT AUTO_INCREMENT PRIMARY KEY,
    id_livro INT NOT NULL,
    id_categoria INT NOT NULL,
    UNIQUE (id_livro, id_categoria),
    CONSTRAINT fk_livro_categoria_livro FOREIGN KEY (id_livro) REFERENCES livro(id_livro) ON DELETE CASCADE,
    CONSTRAINT fk_livro_categoria_categoria FOREIGN KEY (id_categoria) REFERENCES categoria(id_categoria) ON DELETE RESTRICT
);

CREATE TABLE solicitacao_emprestimo (
    id_solicitacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_livro INT NOT NULL,
    status ENUM('Pendente','Aprovada','Recusada') DEFAULT 'Pendente',
    data_solicitacao DATETIME DEFAULT CURRENT_TIMESTAMP,
    observacao TEXT,
    CONSTRAINT fk_solicitacao_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
    CONSTRAINT fk_solicitacao_livro FOREIGN KEY (id_livro) REFERENCES livro(id_livro)
);

CREATE TABLE emprestimo (
    id_emprestimo INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_livro INT NOT NULL,
    id_bibliotecario INT NOT NULL,
    data_emprestimo DATE NOT NULL,
    data_prevista_devolucao DATE NOT NULL,
    data_devolucao DATE,
    status ENUM('Ativo','Devolvido','Atrasado') DEFAULT 'Ativo',
    CONSTRAINT fk_emprestimo_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
    CONSTRAINT fk_emprestimo_livro FOREIGN KEY (id_livro) REFERENCES livro(id_livro),
    CONSTRAINT fk_emprestimo_bibliotecario FOREIGN KEY (id_bibliotecario) REFERENCES usuario(id_usuario)
);

CREATE TABLE reserva (
    id_reserva INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_livro INT NOT NULL,
    data_reserva DATETIME DEFAULT CURRENT_TIMESTAMP,
    posicao_fila INT NOT NULL,
    status ENUM('Ativa','Cancelada','Concluida') DEFAULT 'Ativa',
    CONSTRAINT fk_reserva_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
    CONSTRAINT fk_reserva_livro FOREIGN KEY (id_livro) REFERENCES livro(id_livro)
);

CREATE TABLE multa (
    id_multa INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_emprestimo INT NOT NULL UNIQUE,
    valor DECIMAL(10,2) NOT NULL,
    dias_atraso INT NOT NULL,
    data_geracao DATETIME DEFAULT CURRENT_TIMESTAMP,
    status_pagamento ENUM('Pendente','Pago') DEFAULT 'Pendente',
    CONSTRAINT fk_multa_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
    CONSTRAINT fk_multa_emprestimo FOREIGN KEY (id_emprestimo) REFERENCES emprestimo(id_emprestimo)
);

CREATE TABLE pagamento_multa (
    id_pagamento INT AUTO_INCREMENT PRIMARY KEY,
    id_multa INT NOT NULL,
    valor_pago DECIMAL(10,2) NOT NULL,
    forma_pagamento ENUM('Cartao','Pix','Dinheiro','Boleto') NOT NULL,
    data_pagamento DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_pagamento_multa FOREIGN KEY (id_multa) REFERENCES multa(id_multa)
);

CREATE TABLE relatorio (
    id_relatorio INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tipo_relatorio VARCHAR(100) NOT NULL,
    periodo_inicio DATE,
    periodo_fim DATE,
    data_geracao DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_relatorio_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

CREATE TABLE notificacao (
    id_notificacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tipo VARCHAR(50) NOT NULL,
    assunto VARCHAR(200) NOT NULL,
    mensagem TEXT NOT NULL,
    data_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Enviada','Lida','Erro') DEFAULT 'Enviada',
    CONSTRAINT fk_notificacao_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

INSERT INTO usuario (nome_completo, data_nascimento, telefone, cpf, email, senha, perfil, status) VALUES
('Bibliotecario Teste', '1985-06-15', '(11) 99999-1111', '111.222.333-44', 'bibliotecario@teste.com', '$2y$10$N2dAq7X2Ph0R8Bs9MuTgQOln2UUtm6M2i/6w5O8RrEwV5n4f1PNPu', 'Bibliotecario', 'Ativo'),
('Usuario Teste', '1998-02-20', '(11) 98888-2222', '222.333.444-55', 'usuario@teste.com', '$2y$10$M8m92H5VNw6KmaM2tcikhOn3gOw6BRN0Xg7n4M/8Eo9J9fR7WQ8pG', 'Leitor', 'Ativo');

INSERT INTO endereco (id_usuario, logradouro, numero, complemento, bairro, cidade, estado, cep) VALUES
(1, 'Rua das Flores', '120', 'Bloco A', 'Centro', 'São Paulo', 'SP', '01000-000'),
(2, 'Avenida Brasil', '300', 'Casa', 'Vila Nova', 'São Paulo', 'SP', '02000-000');

INSERT INTO editora (nome_editora, telefone, email, site, status) VALUES
('Editora Nova', '(11) 3000-0000', 'contato@editoranova.com.br', 'https://editoranova.com.br', 'Ativo'),
('Leitura Atual', '(21) 4000-0000', 'contato@leituraatual.com.br', 'https://leituraatual.com.br', 'Ativo');

INSERT INTO autor (nome_autor, data_nascimento, data_morte, status) VALUES
('Machado de Assis', '1839-06-21', '1908-09-29', 'Ativo'),
('Clarice Lispector', '1920-12-10', '1977-12-09', 'Ativo'),
('J. R. R. Tolkien', '1892-01-03', '1973-09-02', 'Ativo');

INSERT INTO categoria (nome_categoria, descricao, status) VALUES
('Romance', 'Obras focadas em narrativas emotivas e relacionamentos.', 'Ativo'),
('Ficção', 'Histórias de imaginação e mundos criados.', 'Ativo'),
('Literatura Brasileira', 'Livros e autores da literatura brasileira.', 'Ativo');

INSERT INTO livro (id_editora, titulo, isbn, classificacao_indicativa, quantidade_total, quantidade_disponivel, imagem_capa, status) VALUES
(1, 'Dom Casmurro', '9788535910668', '12 anos', 5, 4, 'dom-casmurro.jpg', 'Ativo'),
(2, 'A Hora da Estrela', '9788535910903', '14 anos', 3, 2, 'hora-da-estrela.jpg', 'Ativo'),
(1, 'O Hobbit', '9788595084759', '10 anos', 7, 6, 'o-hobbit.jpg', 'Ativo');

INSERT INTO livro_autor (id_livro, id_autor) VALUES
(1, 1),
(2, 2),
(3, 3);

INSERT INTO livro_categoria (id_livro, id_categoria) VALUES
(1, 1),
(1, 3),
(2, 1),
(2, 3),
(3, 2);

INSERT INTO livro (id_editora, titulo, isbn, classificacao_indicativa, quantidade_total, quantidade_disponivel, imagem_capa, status) VALUES
(1, 'O Amor nos Tempos do Cólera', '9788535914841', '14 anos', 5, 5, 'olhos_agua.jpg', 'Ativo'),
(2, 'Orgulho e Preconceito', '9788544001827', '12 anos', 5, 5, 'vantagens_invisivel.jpg', 'Ativo'),
(1, 'Jane Eyre', '9788535911634', '14 anos', 5, 5, 'metamorfose.jpg', 'Ativo'),
(2, 'A Culpa é das Estrelas', '9788580572261', '12 anos', 5, 5, 'ainda_estou_aqui.jpg', 'Ativo'),
(1, 'O Morro dos Ventos Uivantes', '9788535911696', '14 anos', 5, 5, 'dias_perfeitos.jpg', 'Ativo'),
(2, 'Como Eu Era Antes de Você', '9788580573435', '14 anos', 5, 5, 'feliz_ano_velho.jpg', 'Ativo'),
(1, 'Extraordinário', '9788580573015', '10 anos', 5, 5, 'pequeno_principe.jpg', 'Ativo'),
(2, 'O Sol é Para Todos', '9788578270698', '14 anos', 5, 5, 'ideias_para_adiar_fim_mundo.jpg', 'Ativo'),
(1, 'A Menina que Roubava Livros', '9788598078351', '12 anos', 5, 5, 'inferno_dante.jpg', 'Ativo'),
(2, 'Um Dia', '9788580571455', '14 anos', 5, 5, 'suicidas.jpg', 'Ativo'),
(1, 'Duna', '9788576573138', '14 anos', 5, 5, '1984.jpg', 'Ativo'),
(2, 'Fundação', '9788576570595', '12 anos', 5, 5, '2001_odisseia.jpg', 'Ativo'),
(1, 'Neuromancer', '9788576571526', '16 anos', 5, 5, 'encontro_rama.jpg', 'Ativo'),
(2, 'O Fim da Infância', '9788576570830', '12 anos', 5, 5, 'fim_infancia.jpg', 'Ativo'),
(1, 'Eu, Robô', '9788576571209', '12 anos', 5, 5, 'eu_sou_lenda.jpg', 'Ativo'),
(2, 'Solaris', '9788576572398', '12 anos', 5, 5, 'fontes_paraiso.jpg', 'Ativo'),
(1, 'O Problema dos Três Corpos', '9788501104247', '14 anos', 5, 5, 'tempo_marte.jpg', 'Ativo'),
(2, 'A Máquina do Tempo', '9788525430827', '10 anos', 5, 5, 'poeira_lunar.jpg', 'Ativo'),
(1, 'A Mão Esquerda da Escuridão', '9788576572741', '14 anos', 5, 5, 'futuro_ancestral.jpg', 'Ativo'),
(2, 'O Homem do Castelo Alto', '9788576572015', '16 anos', 5, 5, 'coraline.jpg', 'Ativo'),
(1, 'Cem Anos de Solidão', '9788501012078', '14 anos', 5, 5, 'olhos_agua.jpg', 'Ativo'),
(2, 'Vidas Secas', '9788501910176', '12 anos', 5, 5, 'vida_nao_util.jpg', 'Ativo'),
(1, 'Capitães da Areia', '9788535911697', '14 anos', 5, 5, 'amanha_nao_esta_venda.jpg', 'Ativo'),
(2, 'Grande Sertão: Veredas', '9788520926621', '16 anos', 5, 5, 'jantar_secreto.jpg', 'Ativo'),
(1, 'O Auto da Compadecida', '9788520931243', '12 anos', 5, 5, 'it_coisa.jpg', 'Ativo'),
(2, 'Quarto de Despejo', '9788508171273', '14 anos', 5, 5, 'ainda_estou_aqui.jpg', 'Ativo'),
(1, 'Memórias Póstumas de Brás Cubas', '9788535910669', '14 anos', 5, 5, 'livro_1788055661_55fad3cd.jpg', 'Ativo'),
(2, 'A Paixão Segundo G.H.', '9788532507404', '16 anos', 5, 5, 'livro_1789002286_140cd12e.png', 'Ativo'),
(1, 'O Cortiço', '9788535910690', '14 anos', 5, 5, 'livro_1789002635_224b3428.png', 'Ativo'),
(2, 'Iracema', '9788535910676', '12 anos', 5, 5, 'livro_1789002845_bc512096.png', 'Ativo');

INSERT INTO livro_autor (id_livro, id_autor) VALUES
(4, 1), (5, 2), (6, 3), (7, 1), (8, 2), (9, 3), (10, 1), (11, 2), (12, 3), (13, 1),
(14, 3), (15, 1), (16, 2), (17, 3), (18, 1), (19, 2), (20, 3), (21, 1), (22, 2), (23, 3),
(24, 1), (25, 2), (26, 3), (27, 1), (28, 2), (29, 3), (30, 1), (31, 2), (32, 3), (33, 1);

INSERT INTO livro_categoria (id_livro, id_categoria) VALUES
(4, 1), (5, 1), (6, 1), (7, 1), (8, 1), (9, 1), (10, 1), (11, 1), (12, 1), (13, 1),
(14, 2), (15, 2), (16, 2), (17, 2), (18, 2), (19, 2), (20, 2), (21, 2), (22, 2), (23, 2),
(24, 3), (25, 3), (26, 3), (27, 3), (28, 3), (29, 3), (30, 3), (31, 3), (32, 3), (33, 3);


CREATE INDEX idx_usuario_email
ON usuario(email);

CREATE INDEX idx_livro_titulo
ON livro(titulo);

CREATE INDEX idx_livro_isbn
ON livro(isbn);

CREATE INDEX idx_livro_id_editora
ON livro(id_editora);

CREATE INDEX idx_emprestimo_status
ON emprestimo(status);

CREATE INDEX idx_reserva_status
ON reserva(status);

CREATE INDEX idx_multa_status
ON multa(status_pagamento);
